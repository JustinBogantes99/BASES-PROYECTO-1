package conexion_bd_proyecto1;


import Business_Logic_Layer.Country;
import Business_Logic_Layer.Nationality;
import java.awt.event.KeyEvent;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import Value_Object.TableNationality;
import Value_Object.TableCountry;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Justin
 */
public class EditCrearPaisNacionalidad extends javax.swing.JFrame {

    /**
     * Creates new form EditCrearPaisNacionalidad
     */
    String usuarioActual;
    int accionSeleccionada;
    int datoSeleccionado;
    
    
    public EditCrearPaisNacionalidad(String usuario, int accion, int dato) {
        usuarioActual = usuario;
        accionSeleccionada = accion;
        datoSeleccionado = dato;
        initComponents();
        Preparar();
    }
    
    public void Preparar(){
        
        if(datoSeleccionado == 1){ //Nacionalidad
            
            paises.setVisible(false);
            paisCombo.setVisible(false);
            paisText.setVisible(false);
            nuevoPais.setVisible(false);
            nacioCombo.removeAllItems();
            
            if(accionSeleccionada == 1){ //Agregar
                
                nacioCombo.setVisible(false);
                nacionalidades.setVisible(false);                
                
            }else if(accionSeleccionada == 2){//Editar
                
                nuevaNacionalidad.setVisible(false);
                
                Nationality nationality = new Nationality();
                try {
                    
                    ResultSet rs = nationality.getAllNationalities();
                    
                    while(rs.next()){
                        nacioCombo.addItem(rs.getString(1));
                    }
                    
                } catch (SQLException ex) {
                    Logger.getLogger(EditCrearPaisNacionalidad.class.getName()).log(Level.SEVERE, null, ex);
                }
                
                nationality.Close();
                
            }else{//Borrar
                
                nuevaNacionalidad.setVisible(false);
                nacioText.setVisible(false);
                
                Nationality nationality = new Nationality();
                try {
                    
                    ResultSet rs = nationality.getAllNationalities();
                    
                    while(rs.next()){
                        nacioCombo.addItem(rs.getString(1));
                    }
                    
                } catch (SQLException ex) {
                    Logger.getLogger(EditCrearPaisNacionalidad.class.getName()).log(Level.SEVERE, null, ex);
                }
                
                nationality.Close();
                
            }
            
            
            
        }else{ //Pais
            
            nacioCombo.setVisible(false);
            nacioText.setVisible(false);
            nuevaNacionalidad.setVisible(false);
            nacionalidades.setVisible(false);
            paisCombo.removeAllItems();
            
            
            if(accionSeleccionada == 1){ //Agregar
                
                paisCombo.setVisible(false);
                paises.setVisible(false);
                
                
            }else if(accionSeleccionada == 2){ //Editar
                
                nuevoPais.setVisible(false);
                Country country = new Country();
                
                try {
                    
                    ResultSet rs = country.getAllCountries();
                    
                    while(rs.next()){
                        paisCombo.addItem(rs.getString(1));
                    }
                    
                    
                } catch (SQLException ex) {
                    Logger.getLogger(EditCrearPaisNacionalidad.class.getName()).log(Level.SEVERE, null, ex);
                }
                
                country.Close();
                
            }else{//Borrar
                paisText.setVisible(false);
                nuevoPais.setVisible(false);
                Country country = new Country();
                
                try {
                    
                    ResultSet rs = country.getAllCountries();
                    
                    while(rs.next()){
                        paisCombo.addItem(rs.getString(1));
                    }
                    
                    
                } catch (SQLException ex) {
                    Logger.getLogger(EditCrearPaisNacionalidad.class.getName()).log(Level.SEVERE, null, ex);
                }
                
                country.Close();
            }
        }     
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        nuevoPais = new javax.swing.JLabel();
        nacioCombo = new javax.swing.JComboBox<>();
        paisCombo = new javax.swing.JComboBox<>();
        aceptar = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        paises = new javax.swing.JLabel();
        paisText = new javax.swing.JTextField();
        nacionalidades = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        nuevaNacionalidad = new javax.swing.JLabel();
        nacioText = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        nuevoPais.setText("NUEVO PAIS");

        nacioCombo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        nacioCombo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nacioComboActionPerformed(evt);
            }
        });

        paisCombo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        aceptar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MULTIMEDIA/Aceptar.png"))); // NOI18N
        aceptar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                aceptarActionPerformed(evt);
            }
        });

        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MULTIMEDIA/atras.png"))); // NOI18N
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        paises.setText("PAISES");

        paisText.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                paisTextActionPerformed(evt);
            }
        });
        paisText.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                paisTextKeyPressed(evt);
            }
        });

        nacionalidades.setText("NACIONALIDADES");

        jLabel1.setText("DATOS");

        nuevaNacionalidad.setText("NUEVA NACIONALIDAD");

        nacioText.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                nacioTextKeyPressed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(nacionalidades, javax.swing.GroupLayout.PREFERRED_SIZE, 207, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(nuevaNacionalidad)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(paisCombo, 0, 207, Short.MAX_VALUE)
                                    .addComponent(paises, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(nuevoPais)
                                    .addComponent(paisText, javax.swing.GroupLayout.PREFERRED_SIZE, 203, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(nacioCombo, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 207, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(aceptar, javax.swing.GroupLayout.PREFERRED_SIZE, 209, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(nacioText, javax.swing.GroupLayout.PREFERRED_SIZE, 203, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(paises)
                    .addComponent(nuevoPais))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(paisText, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(paisCombo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(nacionalidades)
                            .addComponent(nuevaNacionalidad))
                        .addGap(9, 9, 9)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(nacioCombo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(nacioText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton2))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(0, 106, Short.MAX_VALUE)
                        .addComponent(aceptar)))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void nacioComboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nacioComboActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nacioComboActionPerformed

    private void paisTextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_paisTextActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_paisTextActionPerformed

    private void paisTextKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_paisTextKeyPressed
        char c = evt.getKeyChar();
         if (Character.isLetter(c)|| Character.isWhitespace(c)||Character.isISOControl(c)){
             paisText.setEditable(true);
         }
         else{
             paisText.setEditable(false);
         }
    }//GEN-LAST:event_paisTextKeyPressed

    private void nacioTextKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_nacioTextKeyPressed
        char c = evt.getKeyChar();
         if (Character.isLetter(c)|| Character.isWhitespace(c)||Character.isISOControl(c)){
             nacioText.setEditable(true);
         }
         else{
             nacioText.setEditable(false);
         }
    }//GEN-LAST:event_nacioTextKeyPressed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        new EditarOpciones(usuarioActual, accionSeleccionada).setVisible(true);
        super.dispose();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void aceptarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_aceptarActionPerformed
        // TODO add your handling code here:
        if(datoSeleccionado == 1){ //Nacionalidad
            
            if(accionSeleccionada == 1){ //Agregar
                
                if(nacioText.getText().equals("")){
                    
                    JOptionPane.showMessageDialog(null, "Uno de los espacios Obligatorios ha quedado vacío");
                    
                }else{
                    
                    Nationality nationality = new Nationality();
                    
                    if(nationality.insertNationality(nacioText.getText())){
                        nationality.Close();
                        new EditarOpciones(usuarioActual, accionSeleccionada).setVisible(true);
                        super.dispose();
                    }
                    nationality.Close();
                }
                
            }else if(accionSeleccionada == 2){//Editar
                
                if(nacioText.getText().equals("")||nacioCombo.getSelectedItem() == null){
                    
                    JOptionPane.showMessageDialog(null, "Uno de los espacios Obligatorios ha quedado vacío");
                    
                }else{
                    
                    Nationality nationality = new Nationality();
                    TableNationality idNationality;
                    
                    try {
                        
                        idNationality = nationality.getidNationalityWithNameN((String) nacioCombo.getSelectedItem());
                        
                        if(nationality.updateNationality(idNationality.getId_Nationality(), nacioText.getText())){
                            nationality.Close();
                            new EditarOpciones(usuarioActual, accionSeleccionada).setVisible(true);
                            super.dispose();
                        }
                        
                    } catch (SQLException ex) {
                        Logger.getLogger(EditCrearPaisNacionalidad.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    
                    
                    nationality.Close();
                }
                
            }else{//Borrar
                
                if(nacioCombo.getSelectedItem() == null){
                    
                    JOptionPane.showMessageDialog(null, "No existe una nacionalidad que borrar");
                    
                }else{
                    
                    Nationality nationality = new Nationality();
                    TableNationality idNationality;
                    
                    try {
                        
                        idNationality = nationality.getidNationalityWithNameN((String) nacioCombo.getSelectedItem());
                        
                        if(nationality.deleteNationality(idNationality.getId_Nationality())){
                            nationality.Close();
                            new EditarOpciones(usuarioActual, accionSeleccionada).setVisible(true);
                            super.dispose();
                        }
                        
                    } catch (SQLException ex) {
                        Logger.getLogger(EditCrearPaisNacionalidad.class.getName()).log(Level.SEVERE, null, ex);
                    }

                    nationality.Close();
                }
                
            }
                
                
                
        }else{//Paises
            if(accionSeleccionada == 1){ //Agregar
                if(paisText.getText().equals("")){
                    
                    JOptionPane.showMessageDialog(null, "Uno de los espacios Obligatorios ha quedado vacío");
                    
                }else{
                    
                    Country country = new Country();
                    
                    if(country.insertCountry(paisText.getText())){
                        country.Close();
                        new EditarOpciones(usuarioActual, accionSeleccionada).setVisible(true);
                        super.dispose();
                    }
                    country.Close();
                  
                }

                
            }else if(accionSeleccionada == 2){ //Editar
                if(paisText.getText().equals("")||paisCombo.getSelectedItem() == null){
                    
                    JOptionPane.showMessageDialog(null, "Uno de los espacios Obligatorios ha quedado vacío");
                    
                }else{
                    Country country = new Country();
                    TableCountry idCountry;

                    try {

                        idCountry = country.getCountryidN((String) paisCombo.getSelectedItem());

                        if(country.updateCountry(idCountry.getId_Country(), paisText.getText())){
                            country.Close();
                            new EditarOpciones(usuarioActual, accionSeleccionada).setVisible(true);
                            super.dispose();
                        }

                    } catch (SQLException ex) {
                        Logger.getLogger(EditCrearPaisNacionalidad.class.getName()).log(Level.SEVERE, null, ex);
                    }


                    country.Close();
                }
                
                
            }else{//Borrar
                if(paisCombo.getSelectedItem() == null){
                    
                    JOptionPane.showMessageDialog(null, "Uno de los espacios Obligatorios ha quedado vacío");
                    
                }else{
                    Country country = new Country();
                    TableCountry idCountry;

                    try {

                        idCountry = country.getCountryidN((String) paisCombo.getSelectedItem());
                        
                        if(country.deleteCountry(idCountry.getId_Country())){
                            country.Close();
                            new EditarOpciones(usuarioActual, accionSeleccionada).setVisible(true);
                            super.dispose();
                        }
                        
                    } catch (SQLException ex) {
                        Logger.getLogger(EditCrearPaisNacionalidad.class.getName()).log(Level.SEVERE, null, ex);
                    }

                    country.Close();
                }
                
                
                
            }
            
            
            
            
        }
    }//GEN-LAST:event_aceptarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton aceptar;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JComboBox<String> nacioCombo;
    private javax.swing.JTextField nacioText;
    private javax.swing.JLabel nacionalidades;
    private javax.swing.JLabel nuevaNacionalidad;
    private javax.swing.JLabel nuevoPais;
    private javax.swing.JComboBox<String> paisCombo;
    private javax.swing.JTextField paisText;
    private javax.swing.JLabel paises;
    // End of variables declaration//GEN-END:variables
}
