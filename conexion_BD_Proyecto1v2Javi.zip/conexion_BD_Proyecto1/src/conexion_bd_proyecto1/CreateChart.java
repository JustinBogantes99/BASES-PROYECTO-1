/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conexion_bd_proyecto1;
import javax.swing.JFrame;
import java.util.Locale;
import javax.swing.JFrame;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.labels.PieSectionLabelGenerator;
import org.jfree.chart.labels.StandardPieSectionLabelGenerator;
import org.jfree.chart.plot.PiePlot3D;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;
import org.jfree.util.Rotation;

/**
 *
 * @author Home
 */
public class CreateChart extends JFrame {
    
    String usuarioActual;
    
    public CreateChart(String usuario) {
        usuarioActual = usuario;
        String[] arguments = new String[] {"123"};
        main(arguments);
    }
    
    public static void main (String [] args){
        CreateChart CC = new CreateChart("Prueba de Grafico", "Comparacion en Edades");    
        CC.pack();
        CC.setVisible(true);
    }
    public CreateChart(String appTitle, String chartTitle){
        PieDataset dataset = createDataset();
        JFreeChart chart = createChart(dataset, chartTitle);
        ChartPanel chartPanel = new ChartPanel(chart);
        chartPanel.setPreferredSize(new java.awt.Dimension(642,375));
        setContentPane(chartPanel);
    }
    
    
    private PieDataset createDataset(){
        DefaultPieDataset result = new DefaultPieDataset();
        result.setValue("0-18", 10);
        result.setValue("19-30", 50);
        result.setValue("31-45", 5);
        result.setValue("46-55", 10);
        result.setValue("56-65", 8);
        result.setValue("66-75", 2);
        result.setValue("76-85", 5);
        result.setValue("86-", 10);
        return result;
    }
    
    private JFreeChart createChart(PieDataset dataset, String title){
        JFreeChart chart = ChartFactory.createPieChart3D(title, dataset, true, true, false);
        PieSectionLabelGenerator labelGenerator = new StandardPieSectionLabelGenerator("{0} = {1}");
        PiePlot3D plot = (PiePlot3D) chart.getPlot();
        plot.setStartAngle(0);
        plot.setDirection(Rotation.CLOCKWISE);
        plot.setForegroundAlpha(0.5f);
        plot.setLabelGenerator(labelGenerator);
        return chart;
    }
}


