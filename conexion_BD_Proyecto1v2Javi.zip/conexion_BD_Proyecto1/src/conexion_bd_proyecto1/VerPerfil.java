package conexion_bd_proyecto1;


import Business_Logic_Layer.Canton;
import Business_Logic_Layer.Comunity;
import Business_Logic_Layer.Country;
import Business_Logic_Layer.District;
import Business_Logic_Layer.Email;
import Business_Logic_Layer.Person;
import Business_Logic_Layer.PersonxNationality;
import Business_Logic_Layer.Province;
import Business_Logic_Layer.Telephone;
import Business_Logic_Layer.User;
import conexion_bd_proyecto1.PropuestasN;
import java.sql.*;
import java.text.SimpleDateFormat;
import javax.swing.JOptionPane;
import progra1bd.TableCanton;
import progra1bd.TableComunity;
import Value_Object.TableCountry;
import progra1bd.TableDistrict;
import progra1bd.TableProvince;
import Value_Object.TableTelephone;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Justin
 */
public class VerPerfil extends javax.swing.JFrame {

    /**
     * Creates new form VerPerfil
     */
    String usuarioActual;
    
    public VerPerfil(String usuario) {
        usuarioActual = usuario;
        initComponents();
        Preparar();
    }
    
    public void Preparar(){
        User userinfo = new User();
        Person personinfo = new Person();
        Telephone telephoneinfo = new Telephone();
        Email emailinfo = new Email();
        PersonxNationality allNationalities = new PersonxNationality();
        District cantonid = new District();
        Canton provinceid = new Canton();
        Comunity comunityName = new Comunity();
        Province countryid = new Province();
        Country countryname = new Country();
        
        try{
            SimpleDateFormat b = new SimpleDateFormat("dd/MM/YYYY");
            
            ResultSet rs = userinfo.getAllInfoWithUsername(usuarioActual);
            
            while(rs.next()){
                identificacion.setText(rs.getString(2));
            }
            
            rs = personinfo.getAllInfoWithIdentification(identificacion.getText());
            int id_district =-1;
            while(rs.next()){
                nombre.setText(rs.getNString(1));
                primerApellido.setText(rs.getString(2));
                segundoApellido.setText(rs.getString(3));
                fechaNacimiento.setText(b.format(rs.getDate(4)));
                //photo esta pendiente de poner
                id_district = rs.getInt(6);
            }
            
            
            
            
            rs = emailinfo.getEmailWithIdentification(identificacion.getText());
            
            while(rs.next()){
                email.setText(rs.getString(1));
            }
            
            
            
            rs = telephoneinfo.getTelephone(identificacion.getText());
            
            telefonoCB.removeAllItems();
            
            while(rs.next()){
                telefonoCB.addItem(rs.getString(1));
            }
            
            
            
            rs = allNationalities.getNationalitiesWithidentification(identificacion.getText());
            
            nacionalidadCB.removeAllItems();
            
            while(rs.next()){
                nacionalidadCB.addItem(rs.getString(1));
            }
            
            
            
            TableDistrict nombreDistrict = cantonid.getDistrictNameWithIdDistrict(id_district);
            
            distrito.setText(nombreDistrict.getName());
            
            
            
            nombreDistrict = cantonid.getIdCantonN(id_district); //Usado para contener el id_Canton
            
            TableCanton nombreCanton = provinceid.getCantonName(nombreDistrict.getId_Canton());
            
            canton.setText(nombreCanton.getName());
            
            
            
            nombreCanton = provinceid.getComunityidN(nombreDistrict.getId_Canton());//Usado para contener el id_Comunity
            
            TableComunity selectedComunityName = comunityName.getComunityNameWithId(nombreCanton.getId_Community()); 
            
            comunidad.setText(selectedComunityName.getName());
            
            
            
            nombreCanton = provinceid.getProvinceIdWithId(nombreDistrict.getId_Canton()); //Usado para contener id_Province
            
            TableProvince provinceName = countryid.getProvinceNameWithId(nombreCanton.getId_Province());
            
            provincia.setText(provinceName.getName());
            
            
            
            provinceName = countryid.getCountryIdWithId(nombreCanton.getId_Province()); //Usado para contener id_Country
            
            TableCountry countryName = countryname.getCountryNameWithId(provinceName.getId_Country());
            
            pais.setText(countryName.getName());
            
            
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Error Fatal: "+e);
        }
        
        userinfo.Close();
        personinfo.Close();
        telephoneinfo.Close();
        emailinfo.Close();
        allNationalities.Close();
        cantonid.Close();
        provinceid.Close();
        comunityName.Close();
        countryid.Close();
        countryname.Close();
        
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel18 = new javax.swing.JLabel();
        FOTO = new javax.swing.JLabel();
        ID_LABEL = new javax.swing.JLabel();
        NOMBRE_LABEL = new javax.swing.JLabel();
        Apellido1_LABEL = new javax.swing.JLabel();
        Apellido2_LABEL = new javax.swing.JLabel();
        CORREO_LABEL = new javax.swing.JLabel();
        Telefono_LABEL = new javax.swing.JLabel();
        FECHA_LABEL = new javax.swing.JLabel();
        identificacion = new javax.swing.JLabel();
        nombre = new javax.swing.JLabel();
        primerApellido = new javax.swing.JLabel();
        segundoApellido = new javax.swing.JLabel();
        email = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        fechaNacimiento = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        regresar = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        pais = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        provincia = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        comunidad = new javax.swing.JLabel();
        canton = new javax.swing.JLabel();
        distrito = new javax.swing.JLabel();
        telefonoCB = new javax.swing.JComboBox<>();
        nacionalidadCB = new javax.swing.JComboBox<>();

        jLabel18.setText("jLabel18");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        FOTO.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MULTIMEDIA/User_icon_2.png"))); // NOI18N

        ID_LABEL.setText("IDENTIFICACION");

        NOMBRE_LABEL.setText("NOMBRE");

        Apellido1_LABEL.setText("PRIMER APELLIDO");

        Apellido2_LABEL.setText("SEGUNDO APELLIDO");

        CORREO_LABEL.setText("CORREO ELECTRONICO");

        Telefono_LABEL.setText("TELEFONO");

        FECHA_LABEL.setText("FECHA NACIMIENTO");

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MULTIMEDIA/EDITAR.png"))); // NOI18N
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        regresar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/MULTIMEDIA/atras.png"))); // NOI18N
        regresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                regresarActionPerformed(evt);
            }
        });

        jLabel1.setText("NACIONALIDAD");

        jLabel3.setText("PAIS");

        pais.setText(" ");

        jLabel11.setText("PROVINCIA");

        provincia.setText(" ");

        jLabel13.setText("CANTON");

        jLabel14.setText("DISTRITO");

        jLabel20.setText("COMUNIDAD");

        telefonoCB.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        nacionalidadCB.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(NOMBRE_LABEL, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(Apellido1_LABEL, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 316, Short.MAX_VALUE)
                            .addComponent(Telefono_LABEL, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(CORREO_LABEL, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(identificacion, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(nombre, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(primerApellido, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(segundoApellido, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(email, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(FECHA_LABEL, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(Apellido2_LABEL, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(fechaNacimiento, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(ID_LABEL, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(4, 4, 4)
                        .addComponent(telefonoCB, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, 169, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(0, 1, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(pais, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(provincia, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(46, 46, 46)
                                .addComponent(jLabel15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel19, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(comunidad, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(canton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(distrito, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addComponent(nacionalidadCB, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(115, 115, 115)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButton1, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(regresar)
                                .addGap(15, 15, 15))))
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(104, 104, 104)
                        .addComponent(FOTO, javax.swing.GroupLayout.PREFERRED_SIZE, 213, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(ID_LABEL)
                                        .addGap(15, 15, 15)
                                        .addComponent(identificacion, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(15, 15, 15)
                                        .addComponent(NOMBRE_LABEL))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel1)
                                        .addGap(18, 18, 18)
                                        .addComponent(nacionalidadCB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(15, 15, 15)
                                        .addComponent(jLabel3)))
                                .addGap(15, 15, 15)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(pais, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(nombre, javax.swing.GroupLayout.DEFAULT_SIZE, 20, Short.MAX_VALUE))
                                .addGap(15, 15, 15)
                                .addComponent(Apellido1_LABEL))
                            .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 12, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(15, 15, 15)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(primerApellido, javax.swing.GroupLayout.DEFAULT_SIZE, 20, Short.MAX_VALUE)
                            .addComponent(provincia, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(15, 15, 15)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Apellido2_LABEL)
                            .addComponent(jLabel13))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(canton, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(FOTO, javax.swing.GroupLayout.PREFERRED_SIZE, 221, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(15, 15, 15)
                        .addComponent(segundoApellido, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(15, 15, 15)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(CORREO_LABEL)
                    .addComponent(jLabel14))
                .addGap(12, 12, 12)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(distrito, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel15)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(26, 26, 26)
                                .addComponent(jLabel19)
                                .addGap(265, 265, 265))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(14, 14, 14)
                                .addComponent(jLabel20, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGap(18, 18, 18)
                                .addComponent(comunidad, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(216, 216, 216))))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(email, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(Telefono_LABEL, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(telefonoCB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(FECHA_LABEL)
                        .addGap(18, 18, 18)
                        .addComponent(fechaNacimiento, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(318, 318, 318)
                .addComponent(jButton1)
                .addGap(15, 15, 15)
                .addComponent(regresar)
                .addGap(28, 28, 28))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void regresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_regresarActionPerformed
        // TODO add your handling code here:
        new PropuestasN(usuarioActual).setVisible(true);
        super.dispose();
    }//GEN-LAST:event_regresarActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        new EditarPerfilNuevo(usuarioActual).setVisible(true);
        super.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Apellido1_LABEL;
    private javax.swing.JLabel Apellido2_LABEL;
    private javax.swing.JLabel CORREO_LABEL;
    private javax.swing.JLabel FECHA_LABEL;
    private javax.swing.JLabel FOTO;
    private javax.swing.JLabel ID_LABEL;
    private javax.swing.JLabel NOMBRE_LABEL;
    private javax.swing.JLabel Telefono_LABEL;
    private javax.swing.JLabel canton;
    private javax.swing.JLabel comunidad;
    private javax.swing.JLabel distrito;
    private javax.swing.JLabel email;
    private javax.swing.JLabel fechaNacimiento;
    private javax.swing.JLabel identificacion;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JComboBox<String> nacionalidadCB;
    private javax.swing.JLabel nombre;
    private javax.swing.JLabel pais;
    private javax.swing.JLabel primerApellido;
    private javax.swing.JLabel provincia;
    private javax.swing.JButton regresar;
    private javax.swing.JLabel segundoApellido;
    private javax.swing.JComboBox<String> telefonoCB;
    // End of variables declaration//GEN-END:variables
}
