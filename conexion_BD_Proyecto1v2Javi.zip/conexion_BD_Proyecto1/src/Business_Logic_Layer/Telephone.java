/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business_Logic_Layer;

import Data_Access_Layer.DA_Canton;
import Data_Access_Layer.DA_Telephone;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author admin
 */
public class Telephone {
    private DA_Telephone Telephone;

    public Telephone() {
        Telephone = new DA_Telephone();
    }
    
    public void Close() {
        Telephone.Close();
    }
    
    public ResultSet getTelephone(String Identificacion) throws SQLException{
        return Telephone.getTelephone(Identificacion);
    }

    
    public boolean deleteTelephone(int telephoneNumber) throws SQLException{
        return Telephone.deleteTelephone(telephoneNumber);
    }
    
    public boolean insertTelephone(int telephoneNumber, String identificacion) throws SQLException{
        return Telephone.insertTelephone(telephoneNumber, identificacion);
    }
}









