/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business_Logic_Layer;

import Data_Access_Layer.DA_Country;
import Value_Object.dbConnection;
import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import Value_Object.TableCountry;

/**
 *
 * @author admin
 */
public class Country {
    
    private DA_Country Country;

    public Country() {
        Country = new DA_Country();
    }
    
    public void Close(){
        Country.Close();
    }
    
    public ResultSet getAllCountries() throws SQLException{
        return Country.getAllCountries();
    }
    
    public ResultSet getCountryid(String name)throws SQLException{
        return Country.getCountryid(name);
    }
    
    public TableCountry getCountryidN(String name)throws SQLException{
        ResultSet rs = Country.getCountryid(name);
        TableCountry idCountry = new TableCountry();
        
        while(rs.next()){
            idCountry.setId_Country(rs.getInt(1));
        }
        
        return idCountry;
    }
    
    public TableCountry getCountryNameWithId(int idCountry)throws SQLException{
        ResultSet rs = Country.getCountryNameWithId(idCountry);
        TableCountry countryName = new TableCountry();
        
        while(rs.next()){
            countryName.setName(rs.getString(1));
        }
        return countryName;
    }
    
    public boolean insertCountry(String countryName){
        return Country.insertCountry(countryName);
    }
    
    public boolean updateCountry(int idCountry,String countryName){
        return Country.updateCountry(idCountry, countryName);
    }
    
    public boolean deleteCountry(int idCountry){
        return Country.deleteCountry(idCountry);
    }
}













