/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business_Logic_Layer;

import Data_Access_Layer.DA_Comunity;
import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import progra1bd.TableComunity;


/**
 *
 * @author admin
 */
public class Comunity {
    private DA_Comunity Comunity;
    
    public Comunity(){
        Comunity = new DA_Comunity();
    }
    
    public void Close() {
        Comunity.Close();
    }
    
    public TableComunity getComunityNameWithId(int idComunity) throws SQLException{
        ResultSet rs = Comunity.getComunityNameWithId(idComunity);
        TableComunity comunityName = new TableComunity();
        
        while(rs.next()){
            comunityName.setName(rs.getString(1));
        }
        
        
        return comunityName;
    }
    
}




