/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business_Logic_Layer;

import Data_Access_Layer.DA_Canton;
import Data_Access_Layer.DA_District;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import progra1bd.TableCanton;

/**
 *
 * @author admin
 */
public class Canton {
    private DA_Canton Canton;

    public Canton() {
        Canton = new DA_Canton();
    }
    
    public void Close(){
        Canton.Close();
    }
    
    public ResultSet getCantons(String provinciaSeleccionado) throws SQLException{
        return Canton.getCantons(provinciaSeleccionado);
    }
    
    public ResultSet getCantonid(String name) throws SQLException{
        return Canton.getCantonid(name);
    }
    
    public ResultSet getComunityid(int idCanton) throws SQLException{
        return Canton.getComunityid(idCanton);
    }
    
    public TableCanton getComunityidN(int idCanton) throws SQLException{
        ResultSet rs = Canton.getComunityid(idCanton);
        TableCanton idComunity = new TableCanton();
        
        while(rs.next()){
            idComunity.setId_Community(rs.getInt(1));
        }
        
        return idComunity;
    }
    
    public TableCanton getCantonName(int idCanton) throws SQLException{
        TableCanton nombreCanton = new TableCanton();
        ResultSet rs = Canton.getCantonName(idCanton);
        
        while(rs.next()){
            nombreCanton.setName(rs.getString(1));
        }
        
        return nombreCanton;
    }
    
    public TableCanton getProvinceIdWithId(int idCanton) throws SQLException{
        ResultSet rs = Canton.getProvinceIdWithId(idCanton);
        TableCanton provinceId = new TableCanton();
        
        while(rs.next()){
            provinceId.setId_Province(rs.getInt(1));
        }
        
        return provinceId;
    }
}















