/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business_Logic_Layer;

import Data_Access_Layer.DA_Person;
import Value_Object.dbConnection;
import java.sql.ResultSet;
import java.sql.SQLException;
import Value_Object.TablePerson;

/**
 *
 * @author admin
 */
public class Person {
    private DA_Person Person;
    
    public Person(){
        Person = new DA_Person();
    }
    
    public void Close(){
        Person.Close();
    }
    
    public ResultSet getDistrictidWithUsername(String identification) throws SQLException{
        return Person.getDistrictidWithUsername(identification);
    }
    
    public ResultSet getAllInfoWithIdentification(String identification) throws SQLException{
        return Person.getAllInfoWithIdentification(identification);
    }
    
    public TablePerson getAllInfoWithIdentificationN(String identification) throws SQLException{
        ResultSet rs = Person.getAllInfoWithIdentification(identification);
        TablePerson personInfo = new TablePerson();
        
        while(rs.next()){
            personInfo.setFirst_name(rs.getString(1));
            personInfo.setFirst_last_name(rs.getString(2));
            personInfo.setSecond_Last_name(rs.getString(3));
            personInfo.setBirthdate(rs.getDate(4));
            //photo
            personInfo.setId_district(rs.getInt(6));
            
        }
        return personInfo;
    }
}














