/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business_Logic_Layer;

import Data_Access_Layer.DA_Email;
import Data_Access_Layer.DA_Person;
import java.sql.*;
import progra1bd.TableEmail;
/**
 *
 * @author admin
 */
public class Email {
    private DA_Email Email;
    
    public Email(){
        Email = new DA_Email();
    }
    
    public void Close(){
        Email.Close();
    }
    
    public ResultSet getEmailWithIdentification(String identificacion) throws SQLException{
        return Email.getEmailWithIdentification(identificacion);
    }
    
    public TableEmail getEmailWithIdentificationN(String identificacion) throws SQLException{
        ResultSet rs = Email.getEmailWithIdentification(identificacion);
        TableEmail userEmail = new TableEmail();
        
        while(rs.next()){
            userEmail.setEmail(rs.getString(1));
        }
        return userEmail;
    }
    
}








