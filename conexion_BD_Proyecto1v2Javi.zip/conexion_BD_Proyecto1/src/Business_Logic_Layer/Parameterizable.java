/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business_Logic_Layer;

import Data_Access_Layer.DA_Canton;
import Data_Access_Layer.DA_Parameterizable;
import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import progra1bd.TableParameterizable;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
/**
 *
 * @author admin
 */
public class Parameterizable {
    private DA_Parameterizable Parameterizable;

    public Parameterizable() {
        Parameterizable = new DA_Parameterizable();
    }
    
    public TableParameterizable getIdParameterizable(String name) throws SQLException{
        ResultSet rs = Parameterizable.getIdParameterizable(name);
        TableParameterizable parameterId = new TableParameterizable();
        
        while(rs.next()){
            parameterId.setId_Parameterizable(rs.getInt(1));
        }
        return parameterId;
    }
    
    public void Close(){
        Parameterizable.Close();
    }
    
    public ResultSet getAllParameterizable() throws SQLException {
        return Parameterizable.getAllParameterizable();
    }
    
    public boolean insertParameterizable(String name, int value){
        return Parameterizable.insertParameterizable(name, value);
    }
    
    public boolean updateParameterizable(int idParameter, String name, int value){
        return Parameterizable.updateParameterizable(idParameter, name, value);
    }
}







