/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business_Logic_Layer;

import Data_Access_Layer.DA_Canton;
import Data_Access_Layer.DA_Category;
import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import progra1bd.TableCategory;

/**
 *
 * @author admin
 */
public class Category {
    private DA_Category Category;

    public Category() {
        Category = new DA_Category();
    }
    
    public void Close(){
        Category.Close();
    }
    
    public TableCategory getCategoryNameWithId(int idCategory) throws SQLException{
        ResultSet rs = Category.getCategoryNameWithId(idCategory);
        TableCategory categoryName = new TableCategory();
        
        while(rs.next()){
            categoryName.setName(rs.getString(1));
        }
        
        return categoryName;
    }
    
    public ResultSet getAllCategoryNames () throws SQLException{
        return Category.getAllCategoryNames();
    }
    
    public TableCategory getIdCategoryWithName(String categoryName) throws SQLException{
        
        ResultSet rs = Category.getIdCategoryWithName(categoryName);
        TableCategory categoryNameN = new TableCategory();

        while(rs.next()){
            categoryNameN.setId_Category(rs.getInt(1));
        }
        
        return categoryNameN;
    }
    
    public boolean insertCategory(String name){
        return Category.insertCategory(name);
    }
    
    public boolean updateCategory(int idCategory, String name){
        return Category.updateCategory(idCategory, name);
    }
    
    public boolean deleteCategory(int idCategory){
        return Category.deleteCategory(idCategory);
    }
}







