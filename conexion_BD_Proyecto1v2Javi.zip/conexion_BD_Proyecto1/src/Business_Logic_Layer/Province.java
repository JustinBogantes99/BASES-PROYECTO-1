/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business_Logic_Layer;

import Data_Access_Layer.DA_Province;
import Value_Object.dbConnection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import progra1bd.TableProvince;

/**
 *
 * @author admin
 */
public class Province {
    private DA_Province Province;

    public Province() {
        Province = new DA_Province();
    }
    
    public void Close(){
        Province.Close();
    }
    
    public ResultSet getProvinces(String paisSeleccionado) throws SQLException{
        return Province.getProvinces(paisSeleccionado);
    }
    
    public ResultSet getProvinceid(String name) throws SQLException{
        return Province.getProvinceid(name);
    }
    
    public TableProvince getProvinceNameWithId(int idProvince) throws SQLException{
        ResultSet rs = Province.getProvinceNameWithId(idProvince);
        TableProvince provinceName = new TableProvince();
        
        while(rs.next()){
            provinceName.setName(rs.getString(1));
        }
        
        return provinceName;
    }
    
    public TableProvince getCountryIdWithId(int idProvince) throws SQLException{
        ResultSet rs = Province.getCountryIdWithId(idProvince);
        TableProvince countryId = new TableProvince();
        
        while(rs.next()){
            countryId.setId_Country(rs.getInt(1));
        }
        
        return countryId;
    }
}







