/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business_Logic_Layer;

import Data_Access_Layer.DA_Process;
import Value_Object.dbConnection;
import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author admin
 */
public class Process {
    private DA_Process Process;

    public Process() {
        Process = new DA_Process();
    }
    
    public void Close(){
        Process.Close();
    }
    
    public boolean insertPersonUser(String identificacion, String nombre, String primerApellido, 
            String segundoApellido, String date, int idDistrict, String nombreUsuario, String contraseña,
            String email, int telefono, int idNacionalidad){
        
        return Process.insertPersonUser(identificacion, nombre, primerApellido, segundoApellido, date, 
                idDistrict, nombreUsuario, contraseña, email, telefono,idNacionalidad);
    }
    
    public boolean isAdmin(String username) throws SQLException{
        ResultSet rs = Process.isAdmin(username);
        int userType = 2;
        
        while(rs.next()){
            userType = rs.getInt(1);
        }
        
        if(userType == 1)return true;
        
        return false;
    }
    
    public boolean ascendUser(String Identificacion){
        return Process.ascendUser(Identificacion);
    }
    
    public boolean updatePersonUser(String Identificacion, String firstName, String firstLastname,
                                    String secondLastname, int idDistrict, String email){
        
        return Process.updatePersonUser(Identificacion, firstName, firstLastname, secondLastname, idDistrict, email);
    }
    
    public boolean updatePassword(String username, String password){
        return Process.updatePassword(username, password);
    }
    
}













