/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business_Logic_Layer;


import Data_Access_Layer.DA_CategoryXUser;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author admin
 */
public class CategoryXUser {
    private DA_CategoryXUser CategoryXUser;

    public CategoryXUser() {
        CategoryXUser = new DA_CategoryXUser();
    }
    
    public ResultSet getAllFavoritesfromUser(String username) throws SQLException{
        return CategoryXUser.getAllFavoritesfromUser(username);
    }
    
    public boolean deleteFavorite(int idCategory,String username) throws SQLException{
        return CategoryXUser.deleteFavorite(idCategory, username);
    }
    
    public boolean insertFavorite(int idCategory,String username) throws SQLException{
        return CategoryXUser.insertFavorite(idCategory, username);
    }
}







