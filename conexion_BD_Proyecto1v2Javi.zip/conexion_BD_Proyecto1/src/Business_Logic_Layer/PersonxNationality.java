/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business_Logic_Layer;

import Data_Access_Layer.DA_PersonxNationality;
import Value_Object.dbConnection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author admin
 */
public class PersonxNationality {
    
    private DA_PersonxNationality PersonxNationality;

    public PersonxNationality() {
        PersonxNationality = new DA_PersonxNationality();
    }
    
    public void Close() {
        PersonxNationality.Close();
    }
    
    public ResultSet getNationalitiesWithidentification(String identification) throws SQLException{
        return PersonxNationality.getNationalitiesWithidentification(identification);
    }
    
    public boolean deleteUserNationality(String identification, int idNationality) throws SQLException{
        return PersonxNationality.deleteUserNationality(identification, idNationality);
    }
    
    public boolean insertUserNationality(String identification, int idNationality) throws SQLException{
        return PersonxNationality.insertUserNationality(identification, idNationality);
    }

}






