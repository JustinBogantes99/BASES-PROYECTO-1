/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business_Logic_Layer;

import Data_Access_Layer.DA_User;
import Value_Object.TableUser;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author admin
 */
public class User {
    private DA_User User;
    
    public User(){
        User = new DA_User();
    }
    
    public void Close(){
        User.Close();
    }
    
    public TableUser getMatched(String Username, String Password){
        return User.getMatched(Username, Password);
    }

    public ResultSet getIdentificationWithUsername(String Username) throws SQLException{
        return User.getIdentificationWithUsername(Username);
    }
    
    public TableUser getIdentificationWithUsernameN(String Username) throws SQLException{
        ResultSet rs = User.getIdentificationWithUsername(Username);
        TableUser identificacionUsuario = new TableUser();
        
        while(rs.next()){
            identificacionUsuario.setIdentification(rs.getString(1));
        }
        return identificacionUsuario;
    }
    
    public ResultSet getAllInfoWithUsername(String Username)throws SQLException{
        return User.getAllInfoWithUsername(Username);
    }
    
    public ResultSet getAllCommunUsersUsername()throws SQLException{
        return User.getAllCommunUsersUsername();
    }
}
















