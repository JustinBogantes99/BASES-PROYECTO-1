/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business_Logic_Layer;

import Data_Access_Layer.DA_Proposal;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import Value_Object.TableProposal;

/**
 *
 * @author admin
 */
public class Proposal {
    private DA_Proposal Proposal;
    
    public Proposal(){
        Proposal = new DA_Proposal();
    }
    
    public void Close(){
        Proposal.Close();
    }
    
    public ResultSet getProposals(int comunity) throws SQLException{
        return Proposal.getProposals(comunity);
    }
    
    public ResultSet getFavoriteProposals(int comunity, String identification)throws SQLException{
        return Proposal.getFavoriteProposals(comunity, identification);
    }
    
    public TableProposal getProposalInfoWithTitle(String title) throws SQLException{
        ResultSet rs = Proposal.getProposalInfoWithTitle(title);
        TableProposal proposalInfo = new TableProposal();
        
        while(rs.next()){
            proposalInfo.setId_Category(rs.getInt(1));
            proposalInfo.setUsername(rs.getString(2));
            proposalInfo.setDescription(rs.getString(3));
            proposalInfo.setPost_Date(rs.getDate(4));
            proposalInfo.setBudget(rs.getInt(5));
        }
        return proposalInfo;
    }
    
    public ResultSet getAllMyProposals(String username) throws SQLException{
        return Proposal.getAllMyProposals(username);
    }
    
    public boolean insertProposal(int idCategory, String username, String identification,
                                String title, String descripcion, int budget){
        
        return Proposal.insertProposal(idCategory, username, identification, title, descripcion, budget);
    }
    
    public boolean updateProposal(String titulo, String descripcion, int presupuesto, String antiguoTitulo){
        return Proposal.updateProposal(titulo, descripcion, presupuesto, antiguoTitulo);
    }
    
    public boolean deleteProposal(String titulo){
        return Proposal.deleteProposal(titulo);
    }
}












