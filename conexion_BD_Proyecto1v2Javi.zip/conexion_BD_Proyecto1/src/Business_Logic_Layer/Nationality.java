/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business_Logic_Layer;

import Data_Access_Layer.DA_Nationality;
import Value_Object.dbConnection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import Value_Object.TableNationality;

/**
 *
 * @author admin
 */
public class Nationality {
    
    private DA_Nationality Nationality;

    public Nationality() {
        Nationality = new DA_Nationality();
    }
    
    public void Close(){
        Nationality.Close();
    }
    
    
    public ResultSet getAllNationalities() throws SQLException{
        return Nationality.getAllNationalities();
    }
    
    public ResultSet getidNationalityWithName(String NationalityName) throws SQLException{
        return Nationality.getidNationalityWithName(NationalityName);
    }
    
    public TableNationality getidNationalityWithNameN(String NationalityName) throws SQLException{
        TableNationality nationalityId = new TableNationality();
        ResultSet rs = Nationality.getidNationalityWithName(NationalityName);
        
        while(rs.next()){
            nationalityId.setId_Nationality(rs.getInt(1));
        }
        
        return nationalityId;
    }
    
    public boolean insertNationality(String nationalityName){
        return Nationality.insertNationality(nationalityName);
    }
    
    public boolean updateNationality(int idNationality, String nationalityName){
        return Nationality.updateNationality(idNationality, nationalityName);
    }
    
    public boolean deleteNationality(int idNationality){
        return Nationality.deleteNationality(idNationality);
    }
}












