/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business_Logic_Layer;

import Data_Access_Layer.DA_District;
import Value_Object.dbConnection;
import conexion_bd_proyecto1.CreateUSer;
import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

import progra1bd.TableDistrict;

/**
 *
 * @author admin
 */
public class District {
    
    private DA_District District;
    
    public District(){
        District = new DA_District();
    }
    
    public void Close(){
        District.Close();
    }
    
    
    public int getidDistrict(String name) throws SQLException{
        int id_district = -1;
        ResultSet rs = District.getidDistrict(name);
        
        while(rs.next()){
            id_district = rs.getInt(1);
        }
        
        return id_district;
    }
    
    public ResultSet getDistricts(String cantonSeleccionado) throws SQLException{
        return District.getDistricts(cantonSeleccionado);
    }
    
    public ResultSet getIdCanton(int idDistrict) throws SQLException{
        return District.getIdCanton(idDistrict);
    }
    
    public TableDistrict getIdCantonN(int idDistrict) throws SQLException{
        ResultSet rs = District.getIdCantonN(idDistrict);
        TableDistrict cantonId = new TableDistrict();
        
        while(rs.next()){
            cantonId.setId_Canton(rs.getInt(1));
        }
        
        return cantonId;
    }
    
    public TableDistrict getDistrictNameWithIdDistrict(int idDistrict) throws SQLException{
        ResultSet rs = District.getDistrictNameWithIdDistrict(idDistrict);
        TableDistrict DistrictSeleccionado = new TableDistrict();
        
        while(rs.next()){
            DistrictSeleccionado.setName(rs.getString(1));
        }
        
        return DistrictSeleccionado;
    }
    
}













