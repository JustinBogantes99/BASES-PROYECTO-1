/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Data_Access_Layer;

import Value_Object.dbConnection;
import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author admin
 */
public class DA_Nationality {
    
    private dbConnection conexion;

    public DA_Nationality() {
        conexion = new dbConnection();
    }
    
    public void Close(){
        try {
            conexion.Close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error producido al intentar cerrar la conección con la Base de Datos");
            Logger.getLogger(DA_District.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    
    public ResultSet getAllNationalities() throws SQLException{
        String sql = "Select name from nationality" + " order by name";
        PreparedStatement pst = conexion.PreparedStatement(sql);
        ResultSet rs = pst.executeQuery();
        return rs;
    }
    
    public ResultSet getidNationalityWithName(String NationalityName) throws SQLException{
        String sql = "Select id_nationality from nationality where name = ?";
        PreparedStatement pst = conexion.PreparedStatement(sql);
        pst.setString(1, NationalityName);
        ResultSet rs = pst.executeQuery();
        return rs;
    }
    
    public boolean insertNationality(String nationalityName){
        CallableStatement stmt;
        try {
            stmt = conexion.PrepareCall("call adminNationality.insertNationality(?)");
            stmt.setString(1, nationalityName);
            stmt.execute();
            JOptionPane.showMessageDialog(null, "Nacionalidad agregada Correctamente");
            return true;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al agregadar Nacionalidad, intentelo más tarde");
            //Logger.getLogger(DA_Process.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
    public boolean updateNationality(int idNationality, String nationalityName){
        CallableStatement stmt;
        try {
            stmt = conexion.PrepareCall("call adminNationality.updateNationality(?,?)");
            stmt.setInt(1, idNationality);
            stmt.setString(2, nationalityName);
            stmt.execute();
            JOptionPane.showMessageDialog(null, "Nacionalidad editada Correctamente");
            return true;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al editar la Nacionalidad, intentelo más tarde");
            //Logger.getLogger(DA_Process.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
    public boolean deleteNationality(int idNationality){
        CallableStatement stmt;
        try {
            stmt = conexion.PrepareCall("call adminNationality.removeNationality(?)");
            stmt.setInt(1, idNationality);
            stmt.execute();
            JOptionPane.showMessageDialog(null, "Nacionalidad eliminada Correctamente");
            return true;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al eliminar la Nacionalidad, intentelo más tarde");
            //Logger.getLogger(DA_Process.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
}









