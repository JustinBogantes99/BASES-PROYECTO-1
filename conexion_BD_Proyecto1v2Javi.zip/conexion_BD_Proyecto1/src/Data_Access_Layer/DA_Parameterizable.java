/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Data_Access_Layer;

import Value_Object.dbConnection;
import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
/**
 *
 * @author admin
 */
public class DA_Parameterizable {
    private dbConnection conexion;

    public DA_Parameterizable() {
        conexion = new dbConnection();
    }
    
    public void Close(){
        try {
            conexion.Close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error producido al intentar cerrar la conección con la Base de Datos");
            Logger.getLogger(DA_Canton.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public ResultSet getAllParameterizable() throws SQLException {
        String sql = "Select name from Parameterizable";
        PreparedStatement pst = conexion.PreparedStatement(sql);
        ResultSet rs = pst.executeQuery();
        return rs;
    }
    
    public ResultSet getIdParameterizable(String name) throws SQLException{
        String sql = "Select Id_Parameterizable from Parameterizable where name = ?";
        PreparedStatement pst = conexion.PreparedStatement(sql);
        pst.setString(1, name);
        ResultSet rs = pst.executeQuery();
        return rs;
    }
    
    public boolean insertParameterizable(String name, int value){
        CallableStatement stmt;
        JOptionPane.showMessageDialog(null, "Pasa");
        try {
            stmt = conexion.PrepareCall("call adminParameterizable.insertParameterizable(?,?)");
            stmt.setString(1, name);
            stmt.setInt(2, value);
            stmt.execute();
            JOptionPane.showMessageDialog(null, "Valor parametrizable agregado Correctamente");
            return true;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al crear el Valor parametrizable agregado, intentelo más tarde");
            //Logger.getLogger(DA_Process.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
    public boolean updateParameterizable(int idParameter, String name, int value){
        CallableStatement stmt;
        try {
            stmt = conexion.PrepareCall("call adminParameterizable.updateParameterizable(?,?,?)");
            stmt.setInt(1, idParameter);
            stmt.setString(2, name);
            stmt.setInt(3, value);
            stmt.execute();
            JOptionPane.showMessageDialog(null, "Valor parametrizable editado Correctamente");
            return true;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al editar el Valor parametrizable, intentelo más tarde");
            //Logger.getLogger(DA_Process.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
}







