/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Data_Access_Layer;

import Value_Object.dbConnection;
import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author admin
 */
public class DA_CategoryXUser {
    private dbConnection conexion;

    public DA_CategoryXUser() {
        conexion = new dbConnection();
    }
    
    public ResultSet getAllFavoritesfromUser(String username) throws SQLException{
        String sql = "Select name from categoryxfavorite "
                + "inner join category "
                + "on categoryxfavorite.id_category = category.id_category "
                + "where username = ?";
        PreparedStatement pst = conexion.PreparedStatement(sql);
        pst.setString(1, username);
        ResultSet rs = pst.executeQuery();
        return rs;
    }
    
    public boolean deleteFavorite(int idCategory,String username) throws SQLException{
        CallableStatement stmt;
        try{
            String sql = "call adminCategoryxFavorite.removeCategoryxFavorite(?, ?)";
            stmt = conexion.PrepareCall(sql);
            stmt.setString(1, username);
            stmt.setInt(2, idCategory);
            stmt.execute();
            
            JOptionPane.showMessageDialog(null, "Categoría favorita borrada exitosamente");
            return true;
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null, "Se ha producido un error al borrar su Categoría favorita, intentelo más tade");
            //JOptionPane.showMessageDialog(null, ex);
        }
        return false;
    }
    
    public boolean insertFavorite(int idCategory, String username) throws SQLException{
        CallableStatement stmt;
        try{
            String sql = "call adminCategoryxFavorite.insertCategoryxFavorite(?, ?)";
            stmt = conexion.PrepareCall(sql);
            stmt.setString(1, username);
            stmt.setInt(2, idCategory);
            stmt.execute();
            
            JOptionPane.showMessageDialog(null, "Categoría favorita ingresada exitosamente");
            return true;
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null, "Se ha producido un error al ingresar su Categoría favorita, intentelo más tade");
            JOptionPane.showMessageDialog(null, ex);
        }
        return false;
    }
}







