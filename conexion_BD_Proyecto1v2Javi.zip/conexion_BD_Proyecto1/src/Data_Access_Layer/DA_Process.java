/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Data_Access_Layer;

import Value_Object.dbConnection;
import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author admin
 */
public class DA_Process {
    private dbConnection conexion;

    public DA_Process() {
        conexion = new dbConnection();
    }
    
    public void Close(){
        try {
            conexion.Close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error producido al intentar cerrar la conección con la Base de Datos");
            Logger.getLogger(DA_District.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    
    public boolean insertPersonUser(String identificacion, String nombre, String primerApellido, 
            String segundoApellido, String date, int idDistrict, String nombreUsuario, String contraseña,
            String email, int telefono, int idNacionalidad){
        
        CallableStatement stmt;
        
        try {
            stmt = conexion.PrepareCall("call insertPersonUser"
                    + "(?,?,?,?,to_date(?,'dd/MM/YYYY'),?,?,?,?,?,?)");
            
            stmt.setString(1, identificacion);
            stmt.setString(2, nombre);
            stmt.setString(3, primerApellido);
            stmt.setString(4, segundoApellido);
            stmt.setString(5, date);
            stmt.setInt(6, idDistrict);
            stmt.setString(7, nombreUsuario);
            stmt.setString(8, contraseña);
            stmt.setString(9, email);
            stmt.setInt(10, telefono);
            stmt.setInt(11, idNacionalidad);
            
            stmt.execute();
            JOptionPane.showMessageDialog(null, "Datos Ingresados Correctamente");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Uno de los datos ingresados está repetido o no es correcto\n"
                    + "Compruebe los datos e intentelo de nuevo");
            //Logger.getLogger(Process.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        return true;
    }
    
    public ResultSet isAdmin(String username) throws SQLException{
        CallableStatement stmt;
        stmt = conexion.PrepareCall("Select isAdmin(?) "
                + "from dual");
        stmt.setString(1, username);
        ResultSet rs = stmt.executeQuery();
        return rs;
    }
    
    public boolean ascendUser(String Identificacion){
        CallableStatement stmt;
        try {
            stmt = conexion.PrepareCall("call ASCENDTOADMIN(?)");
            stmt.setString(1, Identificacion);
            stmt.execute();
            JOptionPane.showMessageDialog(null, "Usuario ascendido a Administrador Correctamente");
            return true;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al ascender al nuevo Administrador, intentelo más tarde");
            //Logger.getLogger(DA_Process.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
    public boolean updatePersonUser(String Identificacion, String firstName, String firstLastname,
                                    String secondLastname, int idDistrict, String email){
        CallableStatement stmt;
        try {
            stmt = conexion.PrepareCall("call updatePersonUser(?,?,?,?,?,?)");
            stmt.setString(1, Identificacion);
            stmt.setString(2, firstName);
            stmt.setString(3, firstLastname);
            stmt.setString(4, secondLastname);
            stmt.setInt(5, idDistrict);
            stmt.setString(6, email);
            
            stmt.execute();
            JOptionPane.showMessageDialog(null, "Usuario Editado Correctamente");
            return true;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al editar al usuario, intentelo más tarde");
            //Logger.getLogger(DA_Process.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
    public boolean updatePassword(String username, String password){
        CallableStatement stmt;
        try {
            stmt = conexion.PrepareCall("call changePassword(?,?)");
            stmt.setString(1, username);
            stmt.setString(2, password);
            
            stmt.execute();
            JOptionPane.showMessageDialog(null, "Contraseña Editada Correctamente");
            return true;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al editar la contraseña, intentelo más tarde");
            //Logger.getLogger(DA_Process.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
    public ResultSet getAllUsersGroups(String countryName, String provinceName, String cantonName, int caso) throws SQLException{
        String sql;
        if(caso == 0){
            sql = "Select country.name, count(1) ";
        }else if(caso == 1){
            sql = "Select province.name, count(1) ";
        }else if(caso == 2){
            sql = "Select canton.name, count(1) ";
        }else{
            sql = "Select district.name, count(1) ";
        }
        
        sql =   sql+"from person " +
                "inner join district " +
                "on person.id_district = district.id_district " +
                "inner join canton " +
                "on district.id_canton = canton.id_canton " +
                "inner join province " +
                "on canton.id_province = province.id_province " +
                "inner join country " +
                "on province.id_country = country.id_country ";
        
        if(caso == 1){
            sql = sql+"where country.name = ? ";
        }else if(caso == 2){
            sql = sql+"where province.name = ? ";
        }else if(caso == 3){
            sql = sql+"where canton.name = ? ";
        }
        
        
        if(caso == 0){
                sql = sql+"group by country.name";
        }else if(caso == 1){
            sql = sql+"group by province.name";
        }else if(caso == 2){
            sql = sql+"group by canton.name";
        }else{
            sql = sql+"group by district.name";
        }
        
        
        
        PreparedStatement pst = conexion.PreparedStatement(sql);
        
        if(caso == 1){
            pst.setString(1, countryName);
        }else if(caso == 2){
            pst.setString(1, provinceName);
        }else if(caso == 3){
            pst.setString(1, cantonName);
        }

        ResultSet rs = pst.executeQuery();
        return rs;
    }
    
    
}






















