/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Data_Access_Layer;

import Value_Object.dbConnection;
import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author admin
 */
public class DA_District {
    private dbConnection conexion;
    
    public DA_District(){
        conexion = new dbConnection();
    }
    
    public void Close(){
        try {
            conexion.Close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error producido al intentar cerrar la conección con la Base de Datos");
            Logger.getLogger(DA_District.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    
    public ResultSet getidDistrict(String name) throws SQLException{
        CallableStatement stmt;
        int id_district = -1;
            
        stmt = conexion.PrepareCall("Select id_district from district where name = ?");
        stmt.setString(1, name);
        ResultSet rs = stmt.executeQuery();
        return rs;
    }
    
    public ResultSet getDistricts(String cantonSeleccionado) throws SQLException{
        String sql = "Select name from district where id_canton = ?"+" order by name";
        PreparedStatement pst = conexion.PreparedStatement(sql);
        pst.setString(1, cantonSeleccionado);
        ResultSet rs = pst.executeQuery();
        return rs;
    }
    
    public ResultSet getIdCanton(int idDistrict) throws SQLException{
        String sql = "Select id_canton from district where id_district = ?";
        PreparedStatement pst = conexion.PreparedStatement(sql);
        pst.setInt(1, idDistrict);
        ResultSet rs = pst.executeQuery();
        return rs;
    }
    
    public ResultSet getIdCantonN(int idDistrict) throws SQLException{
        String sql = "Select id_canton from district where id_district = ?";
        PreparedStatement pst = conexion.PreparedStatement(sql);
        pst.setInt(1, idDistrict);
        ResultSet rs = pst.executeQuery();
        return rs;
    }
    
    public ResultSet getDistrictNameWithIdDistrict(int idDistrict) throws SQLException{
        String sql = "Select name from district where id_District = ?";
        PreparedStatement pst = conexion.PreparedStatement(sql);
        pst.setInt(1, idDistrict);
        ResultSet rs = pst.executeQuery();
        return rs;
    }
}











