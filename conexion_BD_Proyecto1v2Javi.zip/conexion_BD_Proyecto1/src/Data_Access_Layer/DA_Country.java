/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Data_Access_Layer;

import Value_Object.dbConnection;
import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author admin
 */
public class DA_Country {
    
    private dbConnection conexion;

    public DA_Country() {
        conexion = new dbConnection();
    }
    
    public void Close(){
        try {
            conexion.Close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error producido al intentar cerrar la conección con la Base de Datos");
            Logger.getLogger(DA_District.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public ResultSet getAllCountries() throws SQLException{
        String sql = "Select name from country" + " order by name";
        PreparedStatement pst = conexion.PreparedStatement(sql);
        ResultSet rs = pst.executeQuery();
        return rs;
    }
    
    public ResultSet getCountryid(String name)throws SQLException{
        String sql = "Select id_country from country where name = ?";
        PreparedStatement pst = conexion.PreparedStatement(sql);
        pst.setString(1, name);
        ResultSet rs = pst.executeQuery();
        return rs;
    }
    
    public ResultSet getCountryNameWithId(int idCountry)throws SQLException{
        String sql = "Select name from country where id_Country = ?";
        PreparedStatement pst = conexion.PreparedStatement(sql);
        pst.setInt(1, idCountry);
        ResultSet rs = pst.executeQuery();
        return rs;
    }
    
    
    public boolean insertCountry(String countryName){
        CallableStatement stmt;
        try {
            stmt = conexion.PrepareCall("call adminCountry.insertCountry(?)");
            stmt.setString(1, countryName);
            stmt.execute();
            JOptionPane.showMessageDialog(null, "Pais agregado Correctamente");
            return true;
        } catch (SQLException ex) {
            //JOptionPane.showMessageDialog(null, "Error al agregar la Pais, intentelo más tarde");
            Logger.getLogger(DA_Process.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
    public boolean updateCountry(int idCountry, String countryName){
        CallableStatement stmt;
        try {
            stmt = conexion.PrepareCall("call adminCountry.updateCountry(?,?)");
            stmt.setInt(1, idCountry);
            stmt.setString(2, countryName);
            stmt.execute();
            JOptionPane.showMessageDialog(null, "Pais editado Correctamente");
            return true;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al editar la Pais, intentelo más tarde");
            //Logger.getLogger(DA_Process.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
    public boolean deleteCountry(int idCountry){
        CallableStatement stmt;
        try {
            stmt = conexion.PrepareCall("call adminCountry.removeCountry(?)");
            stmt.setInt(1, idCountry);
            stmt.execute();
            JOptionPane.showMessageDialog(null, "Pais eliminado Correctamente");
            return true;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al eliminar al Pais, intentelo más tarde");
            //Logger.getLogger(DA_Process.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
}










