/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Data_Access_Layer;

import Value_Object.dbConnection;
import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author admin
 */
public class DA_Proposal {
    private dbConnection conexion;
    
    public DA_Proposal(){
        conexion = new dbConnection();
    }
    
    public void Close(){
        try {
            conexion.Close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error producido al intentar cerrar la conección con la Base de Datos");
            Logger.getLogger(DA_District.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public ResultSet getProposals(int comunity) throws SQLException{
        String sql = "Select title from proposal where id_comunity = ?";
        PreparedStatement pst = conexion.PreparedStatement(sql);
        pst.setInt(1, comunity);
        ResultSet rs = pst.executeQuery();
        return rs;
    }
    
    public ResultSet getFavoriteProposals(int comunity, String identification) throws SQLException{
        String sql = "Select title from proposal where id_comunity = ? and id_category in (Select id_category from categoryxfavorite where identification = ?)";
        PreparedStatement pst = conexion.PreparedStatement(sql);
        pst.setInt(1, comunity);
        pst.setString(2, identification);
        ResultSet rs = pst.executeQuery();
        return rs;
    }
    
    public ResultSet getProposalInfoWithTitle(String title) throws SQLException{
        String sql = "Select id_category, username, description, post_date, budget from proposal where title = ?";
        PreparedStatement pst = conexion.PreparedStatement(sql);
        pst.setString(1, title);
        ResultSet rs = pst.executeQuery();
        return rs;
    }
    
    public ResultSet getAllMyProposals(String username) throws SQLException{
        String sql = "Select title from proposal where username = ?";
        PreparedStatement pst = conexion.PreparedStatement(sql);
        pst.setString(1, username);
        ResultSet rs = pst.executeQuery();
        return rs;
    }
    
    public boolean insertProposal(int idCategory, String username, String identification,
                                String title, String descripcion, int budget){
        
        CallableStatement stmt;
        try {
            
            stmt = conexion.PrepareCall("call adminProposal.insertProposal(?,?,?,?,?,?)");
            stmt.setInt(1, idCategory);
            stmt.setString(2, username);
            stmt.setString(3, identification);
            stmt.setString(4, title);
            stmt.setString(5, descripcion);
            stmt.setInt(6, budget);
            
            stmt.execute();
            JOptionPane.showMessageDialog(null, "Propuesta registrada Correctamente");
            return true;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al crear propuesta, intentelo más tarde");
            //Logger.getLogger(DA_Process.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
    public boolean updateProposal(String titulo, String descripcion, int presupuesto, String antiguoTitulo){
        PreparedStatement stmt;
        try {
            
            stmt = conexion.PreparedStatement("update proposal set title = ?, description = ?, budget = ? where title = ?");
            stmt.setString(1, titulo);
            stmt.setString(2, descripcion);
            stmt.setInt(3, presupuesto);
            stmt.setString(4, antiguoTitulo);
            
            stmt.execute();
            JOptionPane.showMessageDialog(null, "Propuesta alterada Correctamente");
            return true;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al alterar propuesta, intentelo más tarde");
            //Logger.getLogger(DA_Process.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
    public boolean deleteProposal(String titulo){
        CallableStatement stmt;
        try {
            
            stmt = conexion.PrepareCall("call adminProposal.removeProposal(?)");
            stmt.setString(1, titulo);
            
            
            stmt.execute();
            JOptionPane.showMessageDialog(null, "Propuesta Eliminada Correctamente");
            return true;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al eliminar propuesta, intentelo más tarde");
            //Logger.getLogger(DA_Process.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
}

















