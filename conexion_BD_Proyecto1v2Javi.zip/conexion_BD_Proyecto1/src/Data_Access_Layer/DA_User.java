/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Data_Access_Layer;

import Value_Object.TableUser;
import Value_Object.dbConnection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author admin
 */
public class DA_User {
    private dbConnection conexion;
    
    public DA_User(){
        conexion = new dbConnection();
    }
    
    public void Close(){
        try {
            conexion.Close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error producido al intentar cerrar la conección con la Base de Datos");
            Logger.getLogger(DA_District.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    
    
    public TableUser getMatched(String Username, String Password){
        TableUser possibleMatched = new TableUser();
        try{
            String sql = "Select * from usuario where username=? and password=?";
            PreparedStatement pst = conexion.PreparedStatement(sql);
            pst.setString(1, Username);
            pst.setString(2, Password);
            ResultSet rs = pst.executeQuery();
            

            if(rs.next()){
                possibleMatched.setUsername(rs.getString(1));
                possibleMatched.setPassword(rs.getString(2));
            }else{
                possibleMatched.setUsername("");
                possibleMatched.setPassword("");
            }
            
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
        
        return possibleMatched;
    }
    
    public ResultSet getIdentificationWithUsername(String Username) throws SQLException{
        String sql = "Select identification from usuario where username = ?";
        PreparedStatement pst = conexion.PreparedStatement(sql);
        pst.setString(1, Username);
        ResultSet rs = pst.executeQuery();
        return rs;
    }
    
    public ResultSet getAllInfoWithUsername(String Username)throws SQLException{
        String sql = "Select username, identification, password from usuario where username = ?";
        PreparedStatement pst = conexion.PreparedStatement(sql);
        pst.setString(1, Username);
        ResultSet rs = pst.executeQuery();
        return rs;
    }
    
    public ResultSet getAllCommunUsersUsername()throws SQLException{
        String sql = "Select username from usuario where not id_user_type = 1"
                + " order by username";
        PreparedStatement pst = conexion.PreparedStatement(sql);
        ResultSet rs = pst.executeQuery();
        return rs;
    }
}













