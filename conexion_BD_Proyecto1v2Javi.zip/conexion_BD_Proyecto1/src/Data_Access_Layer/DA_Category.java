/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Data_Access_Layer;

import Value_Object.dbConnection;
import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import progra1bd.TableCategory;

/**
 *
 * @author admin
 */
public class DA_Category {
    private dbConnection conexion;

    public DA_Category() {
        conexion = new dbConnection();
    }
    
    public void Close(){
        try {
            conexion.Close();
        } catch (SQLException ex) {
            Logger.getLogger(DA_Category.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public ResultSet getCategoryNameWithId(int idCategory) throws SQLException{
        String sql = "Select name from category where id_category = ?";
        PreparedStatement pst = conexion.PreparedStatement(sql);
        pst.setInt(1, idCategory);
        ResultSet rs = pst.executeQuery();
        return rs;
    }
    
    public ResultSet getAllCategoryNames () throws SQLException{
        String sql = "Select name from category";
        PreparedStatement pst = conexion.PreparedStatement(sql);
        ResultSet rs = pst.executeQuery();
        return rs;
    }
    
    public ResultSet getIdCategoryWithName(String categoryName) throws SQLException{
        String sql = "Select id_category from category where name = ?";
        PreparedStatement pst = conexion.PreparedStatement(sql);
        pst.setString(1, categoryName);
        ResultSet rs = pst.executeQuery();
        return rs;
    }
    
    public boolean insertCategory(String name){
        CallableStatement stmt;
        try {
            stmt = conexion.PrepareCall("call adminCategory.insertCategory(?)");
            stmt.setString(1, name);
            stmt.execute();
            JOptionPane.showMessageDialog(null, "Categoria insertada Correctamente");
            return true;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al insertar Categoria, intentelo más tarde");
            //Logger.getLogger(DA_Process.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
    public boolean updateCategory(int idCategory, String name){
        CallableStatement stmt;
        try {
            stmt = conexion.PrepareCall("call adminCategory.updateCategory(?,?)");
            stmt.setInt(1, idCategory);
            stmt.setString(2, name);
            stmt.execute();
            JOptionPane.showMessageDialog(null, "Categoria editada Correctamente");
            return true;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al editar Categoria, intentelo más tarde");
            //Logger.getLogger(DA_Process.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
    public boolean deleteCategory(int idCategory){
        CallableStatement stmt;
        try {
            stmt = conexion.PrepareCall("call adminCategory.removeCategory(?)");
            stmt.setInt(1, idCategory);
            stmt.execute();
            JOptionPane.showMessageDialog(null, "Categoria eliminada Correctamente");
            return true;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al eliminar Categoria, intentelo más tarde");
            //Logger.getLogger(DA_Process.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
}











