/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Data_Access_Layer;

import Value_Object.dbConnection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.CallableStatement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
/**
 *
 * @author admin
 */
public class DA_Telephone {
    private dbConnection conexion;

    public DA_Telephone() {
        conexion = new dbConnection();
    }
    
    public void Close() {
        try {
            conexion.Close();
        } catch (SQLException ex) {
            Logger.getLogger(DA_Telephone.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public ResultSet getTelephone(String Identificacion) throws SQLException{
        String sql = "Select telephone_number from telephone where identification = ? "
                + "order by telephone_number";
        PreparedStatement pst = conexion.PreparedStatement(sql);
        pst.setString(1, Identificacion);
        ResultSet rs = pst.executeQuery();
        return rs;
    }

    public boolean deleteTelephone(int telephoneNumber) throws SQLException{
        String sql = "call adminTelephone.removeTelephone(?)";
        
        try{
        
            CallableStatement pst = conexion.PrepareCall(sql);
            pst.setInt(1, telephoneNumber);
            pst.execute();
            
            JOptionPane.showMessageDialog(null, "Numero Eliminado Correctamente");
            return true;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Sucedió un error al borrar el número telefonico, intentelo más tarde");
            //Logger.getLogger(Process.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
    public boolean insertTelephone(int telephoneNumber,String identificacion ) throws SQLException{
        String sql = "call adminTelephone.insertTelephone(?, ?)";
        
        try{
            CallableStatement pst = conexion.PrepareCall(sql);
            pst.setInt(1, telephoneNumber);
            pst.setString(2, identificacion);
            pst.execute();
            
            JOptionPane.showMessageDialog(null, "Numero Ingresado Correctamente");
            return true;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Sucedió un error al ingresar el número telefónico, intentelo más tarde");
            //JOptionPane.showMessageDialog(null, ex);
        }
        return false;
    }
    
}













