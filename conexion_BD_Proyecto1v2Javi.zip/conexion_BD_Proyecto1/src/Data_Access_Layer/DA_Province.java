/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Data_Access_Layer;

import Value_Object.dbConnection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author admin
 */
public class DA_Province {
    private dbConnection conexion;

    public DA_Province() {
        conexion = new dbConnection();
    }
    
    public void Close(){
        try {
            conexion.Close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error producido al intentar cerrar la conección con la Base de Datos");
            Logger.getLogger(DA_District.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public ResultSet getProvinces(String paisSeleccionado) throws SQLException{
        String sql = "Select name from province where id_country = ?"+" order by name";
        PreparedStatement pst = conexion.PreparedStatement(sql);
        pst.setString(1, paisSeleccionado);
        ResultSet rs = pst.executeQuery();
        return rs;
    }
    
    public ResultSet getProvinceid(String name) throws SQLException{
        String sql = "Select id_province from province where name = ?";
        PreparedStatement pst = conexion.PreparedStatement(sql);
        pst.setString(1, name);
        ResultSet rs = pst.executeQuery();
        return rs;
    }
    
    public ResultSet getProvinceNameWithId(int idProvince) throws SQLException{
        String sql = "Select name from province where id_Province = ?";
        PreparedStatement pst = conexion.PreparedStatement(sql);
        pst.setInt(1, idProvince);
        ResultSet rs = pst.executeQuery();
        return rs;
    }
    
    public ResultSet getCountryIdWithId(int idProvince) throws SQLException{
        String sql = "Select id_country from province where id_Province = ?";
        PreparedStatement pst = conexion.PreparedStatement(sql);
        pst.setInt(1, idProvince);
        ResultSet rs = pst.executeQuery();
        return rs;
    }
}







