/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Data_Access_Layer;

import Value_Object.dbConnection;
import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author admin
 */
public class DA_PersonxNationality {
    private dbConnection conexion;

    public DA_PersonxNationality() {
        conexion = new dbConnection();
    }
    
    public void Close() {
        try {
            conexion.Close();
        } catch (SQLException ex) {
            Logger.getLogger(DA_PersonxNationality.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public ResultSet getNationalitiesWithidentification(String identification) throws SQLException{
        String sql = "Select name from personxnationality "
                + "inner join nationality "
                + "on personxnationality.id_nationality = nationality.id_nationality "
                + "where identification = ?";
        PreparedStatement pst = conexion.PreparedStatement(sql);
        pst.setString(1, identification);
        ResultSet rs = pst.executeQuery();
        return rs;
    }
    
    public boolean deleteUserNationality(String identification, int idNationality) throws SQLException{
        CallableStatement stmt;
        try{
            String sql = "call adminPersonXNationality.removePersonXNationality(?, ?)";
            stmt = conexion.PrepareCall(sql);
            stmt.setString(1, identification);
            stmt.setInt(2, idNationality);
            stmt.execute();
            
            JOptionPane.showMessageDialog(null, "Nacionalidad borrada exitosamente");
            return true;
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null, "Se ha producido un error al borrar la Nacionalidad, intentelo más tade");
            //JOptionPane.showMessageDialog(null, ex);
        }
        return false;
    }
    
    public boolean insertUserNationality(String identification, int idNationality) throws SQLException{
        CallableStatement stmt;
        try{
            String sql = "call adminPersonXNationality.insertPersonXNationality(?, ?)";
            stmt = conexion.PrepareCall(sql);
            stmt.setString(1, identification);
            stmt.setInt(2, idNationality);
            stmt.execute();
            
            JOptionPane.showMessageDialog(null, "Nacionalidad registrada exitosamente");
            conexion.Close();
            return true;
        }catch(SQLException ex){
            //JOptionPane.showMessageDialog(null, "Se ha producido un error al registrar su Nacionalidad, intentelo más tade");
            JOptionPane.showMessageDialog(null, ex);
        }
        conexion.Close();
        return false;
    }
}













