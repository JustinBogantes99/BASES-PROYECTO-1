/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Data_Access_Layer;

import Value_Object.dbConnection;
import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author admin
 */
public class DA_Comunity {
    private dbConnection conexion;
    
    public DA_Comunity(){
        conexion = new dbConnection();
    }
    
    public void Close() {
        try {
            conexion.Close();
        } catch (SQLException ex) {
            Logger.getLogger(DA_Comunity.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public ResultSet getComunityNameWithId(int idComunity) throws SQLException{
        String sql = "Select name from comunity where id_comunity = ?";
        CallableStatement stmt = conexion.PrepareCall(sql);
        stmt.setInt(1, idComunity);
        ResultSet rs = stmt.executeQuery();
        return rs;
    }
}






