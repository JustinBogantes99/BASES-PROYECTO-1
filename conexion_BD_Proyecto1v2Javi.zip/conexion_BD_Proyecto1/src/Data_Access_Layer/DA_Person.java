/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Data_Access_Layer;

import Value_Object.dbConnection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author admin
 */
public class DA_Person {
    private dbConnection conexion;
    
    public DA_Person(){
        conexion = new dbConnection();
    }
    
    public void Close(){
        try {
            conexion.Close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error producido al intentar cerrar la conección con la Base de Datos");
            Logger.getLogger(DA_District.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public ResultSet getDistrictidWithUsername(String identification) throws SQLException{
        String sql = "Select id_district from person where identification = ?";
        PreparedStatement pst = conexion.PreparedStatement(sql);
        pst.setString(1, identification);
        ResultSet rs = pst.executeQuery();
        return rs;
    }
    
    public ResultSet getAllInfoWithIdentification(String identification) throws SQLException{
        String sql = "Select first_name, first_last_name, second_last_name, birthdate, photo, id_district from person where identification = ?";
        PreparedStatement pst = conexion.PreparedStatement(sql);
        pst.setString(1, identification);
        ResultSet rs = pst.executeQuery();
        return rs;
    }
    
    
}











