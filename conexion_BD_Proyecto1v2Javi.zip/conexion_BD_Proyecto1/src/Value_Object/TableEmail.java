/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package progra1bd;
import java.util.Date;

/**Tabla EMail
 *
 * @author Home
 */
public class TableEmail {
    public String email;
    public String identification;
    public String created_by;
    public Date creation_Date;
    public String modified_by;
    public Date modification_Date;

    public TableEmail() {
    }

    /**
     * 
     * @param email email 
     * @param identification id del person
     * @param created_by user que crea person
     * @param creation_Date date de creacion
     * @param modified_by usuario que modifica
     * @param modification_Date  fecha de modificacion
     */
    public TableEmail(String email, String identification, String created_by, Date creation_Date, String modified_by, Date modification_Date) {
        this.email = email;
        this.identification = identification;
        this.created_by = created_by;
        this.creation_Date = creation_Date;
        this.modified_by = modified_by;
        this.modification_Date = modification_Date;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getIdentification() {
        return identification;
    }

    public void setIdentification(String identification) {
        this.identification = identification;
    }

    public String getCreated_by() {
        return created_by;
    }

    public void setCreated_by(String created_by) {
        this.created_by = created_by;
    }

    public Date getCreation_Date() {
        return creation_Date;
    }

    public void setCreation_Date(Date creation_Date) {
        this.creation_Date = creation_Date;
    }

    public String getModified_by() {
        return modified_by;
    }

    public void setModified_by(String modified_by) {
        this.modified_by = modified_by;
    }

    public Date getModification_Date() {
        return modification_Date;
    }

    public void setModification_Date(Date modification_Date) {
        this.modification_Date = modification_Date;
    }
    
    
}
