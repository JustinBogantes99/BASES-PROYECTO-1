/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package progra1bd;
import java.util.*;

/** Tabla Comentario
 *
 * @author Home
 */
public class TableComentario {
   public int id_Comentario;
   public String identification;
   public int id_Proposal;
   public Date date_And_Hout;
   public String description;
   public String created_by;
   public Date creation_Date;
   public String modified_by;
   public Date modification_Date;

    public TableComentario() {
    }

    /**
     * 
     * @param id_Comentario id del comentario
     * @param identification id de la persona que realiza comentario
     * @param id_Proposal id de la propuesta
     * @param date_And_Hout hora y fecha de la propuesta
     * @param description descripcion de la propuesta
     * @param created_by quien crea la propuesta
     * @param creation_Date fecha creacion de la propuesta
     * @param modified_by quien modifica la propuesta 
     * @param modification_Date fecha que se modifica la propuesta
     */
    public TableComentario(int id_Comentario, String identification, int id_Proposal, Date date_And_Hout, String description, String created_by, Date creation_Date, String modified_by, Date modification_Date) {
        this.id_Comentario = id_Comentario;
        this.identification = identification;
        this.id_Proposal = id_Proposal;
        this.date_And_Hout = date_And_Hout;
        this.description = description;
        this.created_by = created_by;
        this.creation_Date = creation_Date;
        this.modified_by = modified_by;
        this.modification_Date = modification_Date;
    }

    public int getId_Comentario() {
        return id_Comentario;
    }

    public void setId_Comentario(int id_Comentario) {
        this.id_Comentario = id_Comentario;
    }

    public String getIdentification() {
        return identification;
    }

    public void setIdentification(String identification) {
        this.identification = identification;
    }

    public int getId_Proposal() {
        return id_Proposal;
    }

    public void setId_Proposal(int id_Proposal) {
        this.id_Proposal = id_Proposal;
    }

    public Date getDate_And_Hout() {
        return date_And_Hout;
    }

    public void setDate_And_Hout(Date date_And_Hout) {
        this.date_And_Hout = date_And_Hout;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCreated_by() {
        return created_by;
    }

    public void setCreated_by(String created_by) {
        this.created_by = created_by;
    }

    public Date getCreation_Date() {
        return creation_Date;
    }

    public void setCreation_Date(Date creation_Date) {
        this.creation_Date = creation_Date;
    }

    public String getModified_by() {
        return modified_by;
    }

    public void setModified_by(String modified_by) {
        this.modified_by = modified_by;
    }

    public Date getModification_Date() {
        return modification_Date;
    }

    public void setModification_Date(Date modification_Date) {
        this.modification_Date = modification_Date;
    }
   
   
}
