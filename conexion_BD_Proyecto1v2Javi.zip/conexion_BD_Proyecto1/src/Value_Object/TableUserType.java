/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package progra1bd;
import java.util.Date;

/**Tabla Tipo Usuario
 *
 * @author Home
 */
public class TableUserType {
    public int id_User_Type;
    public String name;
    public String created_by;
    public Date creation_Date;
    public String modified_by;
    public Date modification_Date;

    public TableUserType() {
    }

    /**
     * 
     * @param id_User_Type id del tipo de usuario
     * @param name nombre del tipo de usuario
     * @param created_by usuario que crea el tipo de usuario
     * @param creation_Date fecha de cracion
     * @param modified_by usuario que modifica 
     * @param modification_Date fecha de modificacion
     */
    public TableUserType(int id_User_Type, String name, String created_by, Date creation_Date, String modified_by, Date modification_Date) {
        this.id_User_Type = id_User_Type;
        this.name = name;
        this.created_by = created_by;
        this.creation_Date = creation_Date;
        this.modified_by = modified_by;
        this.modification_Date = modification_Date;
    }

    public int getId_User_Type() {
        return id_User_Type;
    }

    public void setId_User_Type(int id_User_Type) {
        this.id_User_Type = id_User_Type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCreated_by() {
        return created_by;
    }

    public void setCreated_by(String created_by) {
        this.created_by = created_by;
    }

    public Date getCreation_Date() {
        return creation_Date;
    }

    public void setCreation_Date(Date creation_Date) {
        this.creation_Date = creation_Date;
    }

    public String getModified_by() {
        return modified_by;
    }

    public void setModified_by(String modified_by) {
        this.modified_by = modified_by;
    }

    public Date getModification_Date() {
        return modification_Date;
    }

    public void setModification_Date(Date modification_Date) {
        this.modification_Date = modification_Date;
    }
    
    
    
}
