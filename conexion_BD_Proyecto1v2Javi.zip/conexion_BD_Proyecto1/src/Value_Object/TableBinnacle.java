/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Value_Object;
import java.util.*;

/** Tabla Binnacle
 *
 * @author Valery
 */
public class TableBinnacle {
    public int id_Binnacle;
    public String username;
    public Date modification_Date;
    public String old_Password;
    public String actual_Password;
    public String created_by;
    public String modified_by;
    public Date creation_Date;

    public TableBinnacle() {
    }

    /**
     * 
     * @param id_Binnacle id del binnacle
     * @param username username
     * @param modification_Date fecha modificacion
     * @param old_Password contrasenia anterior
     * @param actual_Password contrasenia actual
     * @param created_by usuario que lo crea
     * @param modified_by usuario ultimo en modificar
     * @param creation_Date fecha creacion
     */
    public TableBinnacle(int id_Binnacle, String username, Date modification_Date, String old_Password, String actual_Password, String created_by, String modified_by, Date creation_Date) {
        this.id_Binnacle = id_Binnacle;
        this.username = username;
        this.modification_Date = modification_Date;
        this.old_Password = old_Password;
        this.actual_Password = actual_Password;
        this.created_by = created_by;
        this.modified_by = modified_by;
        this.creation_Date = creation_Date;
    }

    public int getId_Binnacle() {
        return id_Binnacle;
    }

    public void setId_Binnacle(int id_Binnacle) {
        this.id_Binnacle = id_Binnacle;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Date getModification_Date() {
        return modification_Date;
    }

    public void setModification_Date(Date modification_Date) {
        this.modification_Date = modification_Date;
    }

    public String getOld_Password() {
        return old_Password;
    }

    public void setOld_Password(String old_Password) {
        this.old_Password = old_Password;
    }

    public String getActual_Password() {
        return actual_Password;
    }

    public void setActual_Password(String actual_Password) {
        this.actual_Password = actual_Password;
    }

    public String getCreated_by() {
        return created_by;
    }

    public void setCreated_by(String created_by) {
        this.created_by = created_by;
    }

    public String getModified_by() {
        return modified_by;
    }

    public void setModified_by(String modified_by) {
        this.modified_by = modified_by;
    }

    public Date getCreation_Date() {
        return creation_Date;
    }

    public void setCreation_Date(Date creation_Date) {
        this.creation_Date = creation_Date;
    }
    
    
    
}

