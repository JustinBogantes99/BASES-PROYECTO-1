/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package progra1bd;

import java.util.Date;

/**Tabla Person X Nacionalidad
 *
 * @author Home
 */
public class TablePersonXNationality {
    public String identification;
    public int id_Nationality;
    public String created_by;
    public Date creation_Date;
    public String modified_by;
    public Date modification_Date;

    public TablePersonXNationality() {
    }

    /**
     * 
     * @param identification id de la persona
     * @param id_Nationality id de la nacionalidad
     * @param created_by user que crea
     * @param creation_Date fecha creacion
     * @param modified_by user que modifica
     * @param modification_Date  fecha modificacion
     */
    public TablePersonXNationality(String identification, int id_Nationality, String created_by, Date creation_Date, String modified_by, Date modification_Date) {
        this.identification = identification;
        this.id_Nationality = id_Nationality;
        this.created_by = created_by;
        this.creation_Date = creation_Date;
        this.modified_by = modified_by;
        this.modification_Date = modification_Date;
    }

    public String getIdentification() {
        return identification;
    }

    public void setIdentification(String identification) {
        this.identification = identification;
    }

    public int getId_Nationality() {
        return id_Nationality;
    }

    public void setId_Nationality(int id_Nationality) {
        this.id_Nationality = id_Nationality;
    }

    public String getCreated_by() {
        return created_by;
    }

    public void setCreated_by(String created_by) {
        this.created_by = created_by;
    }

    public Date getCreation_Date() {
        return creation_Date;
    }

    public void setCreation_Date(Date creation_Date) {
        this.creation_Date = creation_Date;
    }

    public String getModified_by() {
        return modified_by;
    }

    public void setModified_by(String modified_by) {
        this.modified_by = modified_by;
    }

    public Date getModification_Date() {
        return modification_Date;
    }

    public void setModification_Date(Date modification_Date) {
        this.modification_Date = modification_Date;
    }
    
    
}
