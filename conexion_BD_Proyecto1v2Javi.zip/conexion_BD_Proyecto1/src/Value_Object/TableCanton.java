/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package progra1bd;
import java.util.Date;

/**
 *
 * @author Home
 */
public class TableCanton {
    public int id_Canton;
    public int id_Community;
    public int id_Province;
    public String name;
    public String created_by;
    public Date creation_Date;
    public String modified_by;
    public Date modification_Date;

    public TableCanton() {
    }

    /**
     * 
     * @param id_Canton id del canton
     * @param id_Community id de la comunidad
     * @param id_Province id de la provincia 
     * @param name nombre canton
     * @param created_by quien crea el canton
     * @param creation_Date cuando se crea el canton
     * @param modified_by quien modifica el canton
     * @param modification_Date  cuando se modifica el canton
     */
    public TableCanton(int id_Canton, int id_Community, int id_Province, String name, String created_by, Date creation_Date, String modified_by, Date modification_Date) {
        this.id_Canton = id_Canton;
        this.id_Community = id_Community;
        this.id_Province = id_Province;
        this.name = name;
        this.created_by = created_by;
        this.creation_Date = creation_Date;
        this.modified_by = modified_by;
        this.modification_Date = modification_Date;
    }

    public int getId_Canton() {
        return id_Canton;
    }

    public void setId_Canton(int id_Canton) {
        this.id_Canton = id_Canton;
    }

    public int getId_Community() {
        return id_Community;
    }

    public void setId_Community(int id_Community) {
        this.id_Community = id_Community;
    }

    public int getId_Province() {
        return id_Province;
    }

    public void setId_Province(int id_Province) {
        this.id_Province = id_Province;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCreated_by() {
        return created_by;
    }

    public void setCreated_by(String created_by) {
        this.created_by = created_by;
    }

    public Date getCreation_Date() {
        return creation_Date;
    }

    public void setCreation_Date(Date creation_Date) {
        this.creation_Date = creation_Date;
    }

    public String getModified_by() {
        return modified_by;
    }

    public void setModified_by(String modified_by) {
        this.modified_by = modified_by;
    }

    public Date getModification_Date() {
        return modification_Date;
    }

    public void setModification_Date(Date modification_Date) {
        this.modification_Date = modification_Date;
    }
    
    

}
