/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Value_Object;
import java.util.Date;

/** Tabla Nacionalidad
 *
 * @author Home
 */
public class TableNationality {
    public int id_Nationality;
    public String  name;
    public String created_by;
    public Date creation_Date;
    public String modified_by;
    public Date modification_Date;

    public TableNationality() {
    }

    /**
     * 
     * @param id_Nationality id nacionalidad
     * @param name nombre nacionalidad
     * @param created_by usuario crea nacionalidad
     * @param creation_Date fecha crea nacionalidad
     * @param modified_by usuario que modifica nacionalidad
     * @param modification_Date  fecha modificacion nacionalidad
     */
    public TableNationality(int id_Nationality, String name, String created_by, Date creation_Date, String modified_by, Date modification_Date) {
        this.id_Nationality = id_Nationality;
        this.name = name;
        this.created_by = created_by;
        this.creation_Date = creation_Date;
        this.modified_by = modified_by;
        this.modification_Date = modification_Date;
    }

    public int getId_Nationality() {
        return id_Nationality;
    }

    public void setId_Nationality(int id_Nationality) {
        this.id_Nationality = id_Nationality;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCreated_by() {
        return created_by;
    }

    public void setCreated_by(String created_by) {
        this.created_by = created_by;
    }

    public Date getCreation_Date() {
        return creation_Date;
    }

    public void setCreation_Date(Date creation_Date) {
        this.creation_Date = creation_Date;
    }

    public String getModified_by() {
        return modified_by;
    }

    public void setModified_by(String modified_by) {
        this.modified_by = modified_by;
    }

    public Date getModification_Date() {
        return modification_Date;
    }

    public void setModification_Date(Date modification_Date) {
        this.modification_Date = modification_Date;
    }
    
    
}

