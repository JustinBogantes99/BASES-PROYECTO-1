/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package progra1bd;
import java.util.Date;

/**Tabla Comunidad
 *
 * @author Home
 */
public class TableComunity {
    public int id_Comunity;
    public String name;
    public String created_by;
    public Date creation_Date;
    public String modified_by;
    public Date modification_Date;

    public TableComunity() {
    }

    /**
     * 
     * @param id_Comunity id de la comunidad
     * @param name nombre comunidad
     * @param created_by user que crea comunidad
     * @param creation_Date fecha creacion de la comunidad
     * @param modified_by usuario que modifica
     * @param modification_Date  fecha modificacion
     */
    public TableComunity(int id_Comunity, String name, String created_by, Date creation_Date, String modified_by, Date modification_Date) {
        this.id_Comunity = id_Comunity;
        this.name = name;
        this.created_by = created_by;
        this.creation_Date = creation_Date;
        this.modified_by = modified_by;
        this.modification_Date = modification_Date;
    }

    public int getId_Comunity() {
        return id_Comunity;
    }

    public void setId_Comunity(int id_Comunity) {
        this.id_Comunity = id_Comunity;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCreated_by() {
        return created_by;
    }

    public void setCreated_by(String created_by) {
        this.created_by = created_by;
    }

    public Date getCreation_Date() {
        return creation_Date;
    }

    public void setCreation_Date(Date creation_Date) {
        this.creation_Date = creation_Date;
    }

    public String getModified_by() {
        return modified_by;
    }

    public void setModified_by(String modified_by) {
        this.modified_by = modified_by;
    }

    public Date getModification_Date() {
        return modification_Date;
    }

    public void setModification_Date(Date modification_Date) {
        this.modification_Date = modification_Date;
    }
    
    
}


