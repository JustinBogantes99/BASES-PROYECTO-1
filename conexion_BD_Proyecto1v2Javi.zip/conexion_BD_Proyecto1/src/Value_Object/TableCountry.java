/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Value_Object;
import java.util.Date;

/** Tabla Pais
 *
 * @author Home
 */
public class TableCountry {
    public int id_Country;
    public String name;
    public String created_by;
    public Date creation_Date;
    public String modified_by;
    public Date modification_Date;

    public TableCountry() {
    }
    
    /**
     * 
     * @param id_Country id del pais
     * @param name nombre del pais
     * @param created_by usuario que crea pais
     * @param creation_Date fecha en la que se crea pais
     * @param modified_by usuario quien modifica
     * @param modification_Date  fecha en que se modifica
     */
    public TableCountry(int id_Country, String name, String created_by, Date creation_Date, String modified_by, Date modification_Date) {
        this.id_Country = id_Country;
        this.name = name;
        this.created_by = created_by;
        this.creation_Date = creation_Date;
        this.modified_by = modified_by;
        this.modification_Date = modification_Date;
    }

    public int getId_Country() {
        return id_Country;
    }

    public void setId_Country(int id_Country) {
        this.id_Country = id_Country;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCreated_by() {
        return created_by;
    }

    public void setCreated_by(String created_by) {
        this.created_by = created_by;
    }

    public Date getCreation_Date() {
        return creation_Date;
    }

    public void setCreation_Date(Date creation_Date) {
        this.creation_Date = creation_Date;
    }

    public String getModified_by() {
        return modified_by;
    }

    public void setModified_by(String modified_by) {
        this.modified_by = modified_by;
    }

    public Date getModification_Date() {
        return modification_Date;
    }

    public void setModification_Date(Date modification_Date) {
        this.modification_Date = modification_Date;
    }
    
    
}

