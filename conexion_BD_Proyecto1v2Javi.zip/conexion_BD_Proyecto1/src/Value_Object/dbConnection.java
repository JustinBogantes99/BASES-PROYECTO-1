/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Value_Object;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import java.sql.CallableStatement;
/**
 *
 * @author admin
 */
public class dbConnection {
    private Connection Conexion;
    
    public dbConnection(){
    
        try{
    String usuario ="admin";
    String contraseña = "admin";
    Class.forName("oracle.jdbc.OracleDriver");
    String cadenaConexion = "jdbc:oracle:thin:@localhost:1521:dbprueba";
    setConexion(DriverManager.getConnection
            (cadenaConexion,usuario,contraseña));
    
    if( getConexion()!=null)
    {
    //System.out.println("Se ha establecido la conexion con el esquema Proyecto 1");
    }
    else{System.out.println("Error de conexion con la BD");}
    }
    catch(Exception e)
    {e.printStackTrace();}
    
    }
    
    
    public Connection getConexion(){
        return Conexion;
    }
    
    public void setConexion(Connection conexion){
        this.Conexion = conexion;
    }
    
    public PreparedStatement PreparedStatement(String sql) throws SQLException{
        return Conexion.prepareStatement(sql);
    }
    
    public CallableStatement PrepareCall(String sql) throws SQLException{
        return Conexion.prepareCall(sql);
    }
    
    public void Close() throws SQLException{
        Conexion.close();
    }
}







