/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Value_Object;
import java.util.Date;
/**Tabla Propuesta
 *
 * @author Home
 */
public class TableProposal {
    public int id_Proposal;
    public int id_Category;
    public String username;
    public String identification;
    public int id_Comunity;
    public String title;
    public String description;
    public Date post_Date;
    public float budget;
    public String created_by;
    public Date creation_Date;
    public String modified_by;
    public Date modification_Date;

    public TableProposal() {
    }

    /**
     * 
     * @param id_Proposal id propuesta
     * @param id_Category id categoria
     * @param username username
     * @param identification id de la persona
     * @param id_Comunity id de la comunidad
     * @param title titulo propuesta
     * @param description descripcion de la propuesta
     * @param post_Date fecha de post
     * @param budget presupuesto
     * @param created_by user que crea
     * @param creation_Date fecha creacion
     * @param modified_by user que modifica
     * @param modification_Date fecha ultima modificacion
     */
    public TableProposal(int id_Proposal, int id_Category, String username, String identification, int id_Comunity, String title, String description, Date post_Date, float budget, String created_by, Date creation_Date, String modified_by, Date modification_Date) {
        this.id_Proposal = id_Proposal;
        this.id_Category = id_Category;
        this.username = username;
        this.identification = identification;
        this.id_Comunity = id_Comunity;
        this.title = title;
        this.description = description;
        this.post_Date = post_Date;
        this.budget = budget;
        this.created_by = created_by;
        this.creation_Date = creation_Date;
        this.modified_by = modified_by;
        this.modification_Date = modification_Date;
    }

    public int getId_Proposal() {
        return id_Proposal;
    }

    public void setId_Proposal(int id_Proposal) {
        this.id_Proposal = id_Proposal;
    }

    public int getId_Category() {
        return id_Category;
    }

    public void setId_Category(int id_Category) {
        this.id_Category = id_Category;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getIdentification() {
        return identification;
    }

    public void setIdentification(String identification) {
        this.identification = identification;
    }

    public int getId_Comunity() {
        return id_Comunity;
    }

    public void setId_Comunity(int id_Comunity) {
        this.id_Comunity = id_Comunity;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getPost_Date() {
        return post_Date;
    }

    public void setPost_Date(Date post_Date) {
        this.post_Date = post_Date;
    }

    public float getBudget() {
        return budget;
    }

    public void setBudget(float budget) {
        this.budget = budget;
    }

    public String getCreated_by() {
        return created_by;
    }

    public void setCreated_by(String created_by) {
        this.created_by = created_by;
    }

    public Date getCreation_Date() {
        return creation_Date;
    }

    public void setCreation_Date(Date creation_Date) {
        this.creation_Date = creation_Date;
    }

    public String getModified_by() {
        return modified_by;
    }

    public void setModified_by(String modified_by) {
        this.modified_by = modified_by;
    }

    public Date getModification_Date() {
        return modification_Date;
    }

    public void setModification_Date(Date modification_Date) {
        this.modification_Date = modification_Date;
    }
    
    
}

