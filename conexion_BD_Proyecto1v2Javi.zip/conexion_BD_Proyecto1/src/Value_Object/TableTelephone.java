/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Value_Object;
import java.util.Date;

/** Tabla Telefono
 *
 * @author Home
 */
public class TableTelephone {
    public int telephone_Number;
    public String identification;
    public String created_by;
    public Date creation_Date;
    public String modified_by;
    public Date modification_Date;

    public TableTelephone() {
    }

    /**
     * 
     * @param telephone_Number telefono
     * @param identification id de persona
     * @param created_by user que crea telefono
     * @param creation_Date fecha creacion
     * @param modified_by usuario que modifica
     * @param modification_Date fecha ultima modificacion
     */
    public TableTelephone(int telephone_Number, String identification, String created_by, Date creation_Date, String modified_by, Date modification_Date) {
        this.telephone_Number = telephone_Number;
        this.identification = identification;
        this.created_by = created_by;
        this.creation_Date = creation_Date;
        this.modified_by = modified_by;
        this.modification_Date = modification_Date;
    }

    public int getTelephone_Number() {
        return telephone_Number;
    }

    public void setTelephone_Number(int telephone_Number) {
        this.telephone_Number = telephone_Number;
    }

    public String getIdentification() {
        return identification;
    }

    public void setIdentification(String identification) {
        this.identification = identification;
    }

    public String getCreated_by() {
        return created_by;
    }

    public void setCreated_by(String created_by) {
        this.created_by = created_by;
    }

    public Date getCreation_Date() {
        return creation_Date;
    }

    public void setCreation_Date(Date creation_Date) {
        this.creation_Date = creation_Date;
    }

    public String getModified_by() {
        return modified_by;
    }

    public void setModified_by(String modified_by) {
        this.modified_by = modified_by;
    }

    public Date getModification_Date() {
        return modification_Date;
    }

    public void setModification_Date(Date modification_Date) {
        this.modification_Date = modification_Date;
    }
    
    
}

