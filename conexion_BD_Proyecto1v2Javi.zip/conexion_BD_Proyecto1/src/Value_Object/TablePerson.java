/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Value_Object;
import java.util.*;
/**Tabla Persona
 *
 * @author Home
 */
public class TablePerson {
    public String identification;
    public String first_name;
    public String first_last_name;
    public String  second_Last_name;
    public Date birthdate;
    public String photo;
    public String created_by;
    public Date creation_Date;
    public String modified_by;
    public Date modification_Date;
    public int id_district;

    public TablePerson() {
    }

    /**
     * 
     * @param identification id de la persona
     * @param first_name nombre de pila
     * @param first_last_name primer apellido
     * @param second_Last_name segundo apellido
     * @param birthdate ffecha nacimiento
     * @param photo foto
     * @param created_by user crea
     * @param creation_Date fecha creacion
     * @param modified_by usuario que modifica
     * @param modification_Date fecha que modifica
     * @param id_district id de distrito
     */
    

    public TablePerson(String identification, String first_name, String first_last_name, String second_Last_name, Date birthdate, String photo, String created_by, Date creation_Date, String modified_by, Date modification_Date, int id_district) {
        this.identification = identification;
        this.first_name = first_name;
        this.first_last_name = first_last_name;
        this.second_Last_name = second_Last_name;
        this.birthdate = birthdate;
        this.photo = photo;
        this.created_by = created_by;
        this.creation_Date = creation_Date;
        this.modified_by = modified_by;
        this.modification_Date = modification_Date;
        this.id_district = id_district;
    }

    public String getIdentification() {
        return identification;
    }

    public void setIdentification(String identification) {
        this.identification = identification;
    }

    public String getFirst_name() {
        return first_name;
    }

    public void setFirst_name(String first_name) {
        this.first_name = first_name;
    }

    public String getFirst_last_name() {
        return first_last_name;
    }

    public void setFirst_last_name(String first_last_name) {
        this.first_last_name = first_last_name;
    }

    public String getSecond_Last_name() {
        return second_Last_name;
    }

    public void setSecond_Last_name(String second_Last_name) {
        this.second_Last_name = second_Last_name;
    }

    public Date getBirthdate() {
        return birthdate;
    }

    public void setBirthdate(Date birthdate) {
        this.birthdate = birthdate;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public String getCreated_by() {
        return created_by;
    }

    public void setCreated_by(String created_by) {
        this.created_by = created_by;
    }

    public Date getCreation_Date() {
        return creation_Date;
    }

    public void setCreation_Date(Date creation_Date) {
        this.creation_Date = creation_Date;
    }

    public String getModified_by() {
        return modified_by;
    }

    public void setModified_by(String modified_by) {
        this.modified_by = modified_by;
    }

    public Date getModification_Date() {
        return modification_Date;
    }

    public void setModification_Date(Date modification_Date) {
        this.modification_Date = modification_Date;
    }

    public int getId_district() {
        return id_district;
    }

    public void setId_district(int id_district) {
        this.id_district = id_district;
    }
    
    
}


